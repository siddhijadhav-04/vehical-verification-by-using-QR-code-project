<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="beans.*" %>
<%@page import="models.*" %>
<%@page import="java.util.*" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/cust.css">
 
<title> </title>

<script language="Javascript" type="text/javascript">
 

function createRequestObject() {
    var tmpXmlHttpObject;
    if (window.XMLHttpRequest) {
            tmpXmlHttpObject = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        tmpXmlHttpObject = new ActiveXObject("Microsoft.XMLHTTP");
    }

    return tmpXmlHttpObject;
}


var http = createRequestObject();

function makeGetRequest(st) {
   // st=document.frm.state.value;
   
    http.open('get', 'Cities?state=' + st);
    http.onreadystatechange = processResponse;
    http.send(null);
}

function processResponse() {
    if(http.readyState == 4){
        var response = http.responseText;
        document.getElementById('cities').innerHTML = response;
    }
}
 
</script>
</head>
<body><jsp:include page="Top.jsp"></jsp:include>
<div class="container"><div class="row"> <div class="col-md-6"> 
 

<h2>Vehicle Registration</h2>
 
<hr>

<div class="form-group">
 <form name="frm" method="post" action="registerVehicles" enctype="multipart/form-data"><table class="tblform">
	<tr><td>Vehicle Name</td>
	<td><input type="text" name="vehicleName" class="form-control" required></td>
	</tr>
	<tr><td>Owner Name</td>
	<td><input type="text" name="ownerName" class="form-control" required></td>
	</tr>
	<tr><td>Vehicle Type</td>
	<td><input type="text" name="vehicleType" class="form-control" required></td>
	</tr>
	<tr><td>Company</td>
	<td><input type="text" name="company" class="form-control" required></td>
	</tr>
	<tr><td>Chassis  No</td>
	<td><input type="text" name="chesisNo" class="form-control" required>
	 <input type="hidden" name="userid" value="<%=session.getAttribute("userid").toString() %>"/>
	 <input type="hidden" name="usernm" value="<%=session.getAttribute("usernm").toString() %>"/>
	</td></tr>  
	<tr><td>Engine No</td>
	<td><input type="text" name="engineNo" class="form-control" required></td>
	</tr>
	 <tr><td>Details</td>
	<td><textarea name="details" class="form-control"></textarea></td>
	</tr>
 
       
     <%
									 GetStateNCities obj=new GetStateNCities();
									 obj.getStates();
									 List<States> lst=obj.getLststate();
									 %>
									  <tr>
									 <td>State
									 </td>
									 <td> 
									 <select required name="state" class="form-control" onchange="makeGetRequest(this.value)">
									 <option value=""><--select--></option>
										<%for(int i=0;i<lst.size();i++)
											{%>
									 <option value="<%=lst.get(i).getState() %>"><%=lst.get(i).getState() %></option>											
											<%}%>															  
									 </select>
									 </td>
									 </tr>
									   <tr>
									 <td>City
									 </td>
									 <td> 
									<div id="cities"></div>
									 </td>
									 </tr>
       
        
          
	<tr><td>LicenseNo</td>
	<td><input type="text" name="licenseNo" class="form-control" required></td>
	</tr>
      
        
       <tr><td>Vehicle Documents</td>
       <td>
       <input type="file" name="file" class="form-control"/>
       </td>
	<tr>
	<td><input type="submit" value="Submit" class="btn btn-primary" ></td>
	</tr>
	</table>
</form>
</div></div><div class="col-md-6"><br/><br/>
<img src="images/vehicle.avif" width="100%"/>
</div>
</div></div>
</body>
</html>