 
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="soham"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/cust.css">

<title> </title>
<style>
/* Ensures proper spacing and responsive layout */
.card {
    border-radius: 10px;
    border: 1px solid #ddd;
    background: #fff;
    transition: all 0.3s ease-in-out;
}

.card:hover {
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

.card-body {
    padding: 15px;
}

/* Title styling */
.card-title {
    font-size: 30px;
    font-weight: bold;
    color: #333;
}

/* Text and description styles */
.card-text {
    font-size: 14px;
    color: #555;
}

/* Date & Time styling */
.card p {
    font-size:  23px;
    color: #777;
    margin-bottom: 5px;
}

/* Button styling */
.btn-primary {
    font-size: 24px!important;
    padding: 5px 12px;
    border-radius: 5px;
}

.btn-primary:hover {
    background: #0056b3;
    font-size: 24px!important;
}

/* Responsive layout adjustments */
@media (max-width: 768px) {
    .card {
        margin-bottom: 15px;
    }
}

</style>
</head>
<body><jsp:include page="Top2.jsp"></jsp:include>
<%

String userid=String.valueOf(session.getAttribute("userid"));
String usertype=String.valueOf(session.getAttribute("usertype"));
if(!userid.equalsIgnoreCase("null")){	
	
session.setMaxInactiveInterval(10*60);
 
%>
<h2>Documents</h2>
<hr><div class="container">
    <div class="row">
        <soham:forEach items="${std}" var="rec">
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="card shadow-sm p-3">
                    <div class="card-body">
                        <h5 class="card-title">${rec.title}</h5>
                        <p class="card-text"><strong>Description:</strong> ${rec.docdesc}</p>
                        <p class="mb-1"><strong>Date:</strong> ${rec.dt}</p>
                        <p><strong>Time:</strong> ${rec.tm}</p>
                        <form method="post" action="DecryptDoc">
                            <input type="hidden" name="filePath" value="${rec.filePath}" />
                            <input type="hidden" name="docId" value="${rec.docid}" />
                            <input type="hidden" name="seckey" value="${rec.seckey}" />
                            <button type="submit" class="btn btn-primary ">Decrypt</button>
                        </form>
                    </div>
                </div>
            </div>
        </soham:forEach>
    </div>
</div>


<%
if(usertype.equals("admin")){
%> 
<%
}
else{	%>
	 
<%
	}
	
}
else{
	%>
	<h2>Invalid Session...Login again</h2>
	<br>
	<a href="index.jsp">Login</a>
	
	<%
}

%>
</body>
</html>