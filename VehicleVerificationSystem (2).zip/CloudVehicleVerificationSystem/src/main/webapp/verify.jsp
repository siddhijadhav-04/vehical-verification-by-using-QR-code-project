<!DOCTYPE html>
<html lang="en">
<head>
    <title>Cloud Vehicle Verification System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
        .navbar-brand h1 {
            font-size: 4.5rem;
            color:white!important;
            font-weight: bold;
        }
        .jumbotron {
            padding: 2rem;
        }
        .tblform {
            width: 100%;
        }
        .svg-blob, .svg-blob-2 {
            display: none;
        }
        @media (max-width: 768px) {
            .navbar-brand h1 {
                font-size: 1.2rem;
            }
            .svg-blob, .svg-blob-2 {
                display: block;
                max-width: 100%;
                height: auto;
            }
            .login-img {
                width: 100%;
                height: auto;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home"><h1>Cloud Vehicle Verification</h1></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="home" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="#login" class="nav-link">Login</a></li>
                    <li class="nav-item"><a href="#services-section" class="nav-link">Registration</a></li>
                    <li class="nav-item"><a href="#about-section" class="nav-link">About</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <section class="ftco-section testimony-section" id="login">
        <div class="container">
            <div class="row justify-content-center pb-3">
                <div class="col-md-7 text-center">
                    <h2 class="mb-4">Login</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="jumbotron">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <form method="post" action="check">
                                    <div class="form-group">
                                        <label for="userid">User ID</label>
                                        <input type="text" class="form-control" name="userid" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="pswd">Password</label>
                                        <input type="password" class="form-control" name="pswd" required>
                                        <input type="hidden" value="<%=request.getParameter("vid").toString().trim() %>" class="form-control" name="vid" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block">Submit</button>
                                    <div class="text-center mt-2">
                                        <a href="forgetpassword">Forgot Password?</a>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-6 text-center">
                                <img src="images/login.gif" class="login-img" alt="Login">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <footer class="text-center py-3">
        <div class="container">
            <p>&copy; <script>document.write(new Date().getFullYear());</script> All rights reserved</p>
        </div>
    </footer>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
