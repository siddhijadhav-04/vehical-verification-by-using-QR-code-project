a<%@page import="models.LoginTracker"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="soham"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/cust.css">

<title> </title>
</head>
<body><jsp:include page="Top.jsp"></jsp:include>
<%

String userid=String.valueOf(session.getAttribute("userid"));
String usertype=String.valueOf(session.getAttribute("usertype"));
if(!userid.equalsIgnoreCase("null")){	
	
session.setMaxInactiveInterval(10*60);
LoginTracker login=new LoginTracker();
%>
<h2>My Vehicles</h2>
<hr>

<table class="table table-bordered">
<tr>
<th>Vehicle Name</th>
<th>Vehicle Type</th>
<th>Chassis No </th>
<th>Engine No</th>
<th>Details</th> 
<th>Date</th>
<th>Owner Name</th>
<th>Status</th>
<th>Docs</th> 
 <th>Download QR code</th> 
</tr>


<soham:forEach items="${std}" var="rec">

<tr>
<td>${rec.vehicleName}</td>
<td>${rec.vehicleType}</td>
<td>${rec.chesisNo}</td>
<td>${rec.engineNo}</td>
<td>${rec.details}</td> 
<td>${rec.dt}</td>
<td>${rec.ownerName}</td>
<td>${rec.sts}</td>
<td>
<form method="post" action="sendOTP1" target="_blank">
<input type="hidden" name="path" value="${rec.path}"/>
<input type="hidden" name="docId" value="${rec.vid}"/>
<input type="hidden" name="seckey" value="${rec.seckey}"/>
<input type="submit" value="Send Secrete Key on Email" class="btn btn-primary"/>
</form> 

</td>
 <td>
 <soham:choose>
    <soham:when test="${rec.sts eq 'pending'}">
        <!-- Code for pending status -->
        <p>NA</p>
    </soham:when>
    <soham:otherwise>
        <!-- Code for other statuses -->
        <a href="generateQR?vid=${rec.vid}"  class="btn btn-primary" target="_blank">Download QR code</a></td>
    </soham:otherwise>
</soham:choose>
 
  
</tr>

</soham:forEach>
</table>

<%
if(usertype.equals("admin")){
%> 
<%
}
else{	%>
	 
<%
	}
	
}
else{
	%>
	<h2>Invalid Session...Login again</h2>
	<br>
	<a href="index.jsp">Login</a>
	
	<%
}

%>
</body>
</html>