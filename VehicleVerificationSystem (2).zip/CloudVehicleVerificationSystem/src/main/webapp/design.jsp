<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Website Heading</title>
  <style>
    /* General styling */
    body {
      margin: 0;
      font-family: "Arial", sans-serif;
    }

    /* Header div container */
    #headerdiv {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 200px; /* Adjust height as needed */
      background: linear-gradient(135deg, #f8e7e7, #f5c7c7, #e7b3b3);
      background-size: 300% 300%;
      animation: backgroundAnimation 12s ease-in-out infinite;
      border-bottom: 2px solid #f5c7c7; /* Subtle separator for clarity */
    }

    /* Heading text */
    #headerdiv h1 {
      font-size: 3rem;
      font-weight: bold;
      text-transform: uppercase;
      background: linear-gradient(90deg, #ff8a8a, #f5c7c7, #e7b3b3, #ff8a8a);
      background-size: 200% 200%;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      animation: gradientText 10s linear infinite;
      position: relative;
    }

    #headerdiv h1::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(255, 255, 255, 0.05); /* Subtle overlay for style */
      border: 2px solid rgba(255, 200, 200, 0.3); /* Thin glowing border */
      border-radius: 10px;
      z-index: -1;
      animation: borderPulse 8s ease-in-out infinite;
    }

    /* Keyframes for Background Animation */
    @keyframes backgroundAnimation {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    /* Keyframes for Gradient Text Animation */
    @keyframes gradientText {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    /* Keyframes for Border Pulse */
    @keyframes borderPulse {
      0%, 100% { border-color: rgba(255, 200, 200, 0.3); }
      50% { border-color: rgba(255, 200, 200, 0.6); }
    }
  </style>
</head>
<body>
  <!-- Header Div -->
  <div id="headerdiv">
    <h1>Website Heading</h1>
  </div>
</body>
</html>
