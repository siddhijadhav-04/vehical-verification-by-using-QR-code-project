<%@page import="java.util.List"%>
<%@page import="models.LoginTracker"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
  
 <!DOCTYPE html>
<html lang="en">
  <head>
    <title>Vehicle Verification By Using QR COde</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light site-navbar-target" id="ftco-navbar">
	    <div  class="container-fluid head" >
	    <div class="row"> <div  class="col-md- 12   "> 
	      <a class="navbar-brand" href="home"><h1 class="h1"> Vehicle Verification By Using QR Code</h1></a>
	     </div><div class="col-md-12">     <button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav nav ml-auto">
	          <li class="nav-item"><a href="<%=session.getAttribute("usertype").toString().trim()%>" class="nav-link"><span>Home</span></a></li>
	          <%if(session.getAttribute("usertype").toString().trim().equals("cloudadmin"))
                                	{
                                	%>
                                 <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RTO Offices</a>
                <div class="dropdown-menu" aria-labelledby="adminMenu">
                    <a class="dropdown-item" href="regOffice">Register RTO Office</a>
                    <a class="dropdown-item" href="viewOffice">View RTO Offices</a> 
                </div>
            </li>	
            <li class="nav-item"><a class="nav-link" href="viewUsers" >View Users</a></li> 
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Cloud Reports</a>
                <div class="dropdown-menu" aria-labelledby="adminMenu">
                     
                    <a class="dropdown-item" href="MonthlyCloudUsage.jsp?page=admin">Total Cloud Usage</a>
                    <a class="dropdown-item" href="MonthlyCloudRent.jsp">Monthly Cloud Usage Statistics</a>
                    <a class="dropdown-item" href="YearlyPaymentHistory.jsp">Payment Summary</a>
                </div>
            </li>	 
		  
		
								 <%} else if(session.getAttribute("usertype").toString().trim().equals("user"))
                            	{
                            	%>
                            	 <li class="nav-item"><a class="nav-link" href="RegVehicles" >Register Vehicle</a></li>
                            	 
                  <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Documents</a>
                <div class="dropdown-menu" aria-labelledby="adminMenu">
                    <a class="dropdown-item" href="uploaddoc">Upload Documents</a>
                    <a class="dropdown-item" href="insurance">Upload Insurance details</a>
                    <a class="dropdown-item" href="viewdocs">View My Documents</a> 
                    <a class="dropdown-item" href="viewinsurance">View Insurance details</a> 
                    
                </div>
            </li>	
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Cloud Reports</a>
                <div class="dropdown-menu" aria-labelledby="adminMenu">
                    <a class="dropdown-item" href="MonthlyCloudUsage.jsp?page=user">Total Cloud Usage</a>
                    <a class="dropdown-item" href="MonthlyCloudRent.jsp">Monthly Cloud Usage Statistics</a> 
                </div>
            </li>
	   
		 
         
                            	<%} else if(session.getAttribute("usertype").toString().trim().equals("officer"))
                            	{
                            	%>
                            	  <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RTO Police</a>
                <div class="dropdown-menu" aria-labelledby="adminMenu">
                    <a class="dropdown-item" href="regOffice1">Register RTO Police</a>
                    <a class="dropdown-item" href="viewOffice1">View RTO Police Details</a> 
                </div>
            </li>
	    
                            <li class="nav-item"><a  class="nav-link" href="ViewCityPendingApps" >Pending Vehicle Registrations</a></li>
                            <!-- <li class="nav-item"><a  class="nav-link" href="ViewCityApprovedVehicles" >Approved Vehicles</a></li> -->
                             
                             <li class="nav-item"><a  class="nav-link" href="getPendingDocs" >Pending Documents</a></li>
                            
                            
                             <%} %> 
                            	<li class="nav-item"><a  class="nav-link" href="ChangePass">Change Password</a></li>
								<li class="nav-item"><a  class="nav-link" href="logout">Logout</a></li>
                      
    </ul>
</div>
                      
	              </ul>
	      </div>
	    </div>
	  </nav>
	  
	  <section class="hero-wrap hero-wrap-2" style="background-image: url('images/single_banner.jpg');background-size: cover;background-position: center;" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-4">
            <h1 class="mb-3 bread">Logged in as  <%=session.getAttribute("userid").toString() %> (<%=session.getAttribute("usertype").toString() %>)</h1>
           
          </div>
        </div>
      </div>
    </section>
      <div class="container"> 
       
 

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  
  <script src="js/main.js"></script>
       