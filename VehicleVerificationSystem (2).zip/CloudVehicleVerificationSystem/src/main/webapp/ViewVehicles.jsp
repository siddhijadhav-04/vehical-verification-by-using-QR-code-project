<%@page import="models.LoginTracker"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="soham"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/cust.css">

<title> </title>
</head>
<body><jsp:include page="Top.jsp"></jsp:include>
<%

String userid=String.valueOf(session.getAttribute("userid"));
String usertype=String.valueOf(session.getAttribute("usertype"));
if(!userid.equalsIgnoreCase("null")){	
	
session.setMaxInactiveInterval(10*60);
LoginTracker login=new LoginTracker();
%>
<h2>High Speed Vehicles</h2>
<hr>

<table class="table table-bordered">
<tr style="background-color:seashell">
<th>Vehicle Name</th>
<th>Vehicle Type</th>
<th>Chassis No </th>
<th>Engine No</th>
<th>Details</th> 
<th>Date</th>
<th>Owner Name</th>
<th>Status</th>
<th>Docs</th> 

 <th></th>
</tr>


<soham:forEach items="${std}" var="rec">

<tr>
<td>${rec.vehicleName}</td>
<td>${rec.vehicleType}</td>
<td>${rec.chesisNo}</td>
<td>${rec.engineNo}</td>
<td>${rec.details}</td> 
<td>${rec.dt}</td>
<td>${rec.ownerName}</td>
<td>${rec.sts}</td>
<td><a href="Vehicles/${rec.path}" target="_blank">open Docs</a></td>
 <td><a href="SendChallan.jsp?vid=${rec.vid}" >Send Challan</a></td>
   
</tr>

</soham:forEach>
</table>

<%
if(usertype.equals("admin")){
%> 
<%
}
else{	%>
	 
<%
	}
	
}
else{
	%>
	<h2>Invalid Session...Login again</h2>
	<br>
	<a href="index.jsp">Login</a>
	
	<%
}

%>
</body>
</html>