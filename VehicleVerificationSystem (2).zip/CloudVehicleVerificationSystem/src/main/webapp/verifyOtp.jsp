<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>

<h2>Enter OTP</h2>

<form action="checkOtp" method="post">
    <input type="text" name="userOtp" placeholder="Enter OTP" required>
    <br><br>
    <button type="submit">Submit</button>
</form>

<p>${msg}</p>

</body>
</html>