<!DOCTYPE html>
<html lang="en">
<head>
    <title> Vehicle Verification By Using QR Code</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        .navbar-brand h1 {
            font-size: 20px;
            color:white!important;
        }
        @media (max-width: 768px) {
            .navbar-brand h1 {
                font-size: 2rem;
            }
            .hero-wrap {
                text-align: center;
                padding: 50px 20px;
            }
            .hero-wrap h1 {
                font-size: 3.2rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home">
                <h1> Vehicle Verification By Using QR Code</h1>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="<%=session.getAttribute("usertype")%>" class="nav-link">Home</a></li>
                    <% if (session.getAttribute("usertype").equals("cloudadmin")) { %>
                        <li class="nav-item"><a href="viewUsers" class="nav-link">View Users</a></li>
                    <% } %>
                    <li class="nav-item"><a href="ChangePass" class="nav-link">Change Password</a></li>
                    <li class="nav-item"><a href="logout" class="nav-link">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <section class="hero-wrap" style="background-image: url('images/single_banner.jpg'); background-size: cover; background-position: center; padding: 50px 0;height: 300px">
        <div class="container text-center">
            <h1 style="color:white">Logged in as <%=session.getAttribute("userid")%> (<%=session.getAttribute("usertype")%>)</h1>
        </div>
    </section>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
