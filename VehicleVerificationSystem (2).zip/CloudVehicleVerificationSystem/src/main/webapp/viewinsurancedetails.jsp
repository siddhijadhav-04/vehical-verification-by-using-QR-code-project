<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="soham"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="ISO-8859-1">

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/cust.css">

<title>Insurance Details</title>

</head>

<body>

<jsp:include page="Top.jsp"></jsp:include>

<%

String userid=String.valueOf(session.getAttribute("userid"));

String usertype=String.valueOf(session.getAttribute("usertype"));

if(!userid.equalsIgnoreCase("null")){

session.setMaxInactiveInterval(10*60);

%>

<h2>My Insurance Details</h2>

<hr>

<table class="table table-bordered">

<tr style="background-color:seashell">

<th>Company</th>
<th>Policy No</th>
<th>Insurance Type</th>
<th>Start Date</th>
<th>Expiry Date</th>
<th>Amount</th>
<th>Description</th>
<th>Status</th>
<th>Document</th>

</tr>

<soham:forEach items="${std}" var="rec">

<tr>

<td>${rec.company}</td>

<td>${rec.policyno}</td>

<td>${rec.instype}</td>

<td>${rec.startdt}</td>

<td>${rec.expdt}</td>

<td>${rec.amount}</td>

<td>${rec.description}</td>

<td>${rec.sts}</td>

<td>

<form method="post" action="sendInsuranceOTP">

<input type="hidden"
       name="path"
       value="${rec.filePath}"/>

<input type="hidden"
       name="insuranceId"
       value="${rec.id}"/>

<input type="hidden"
       name="seckey"
       value="${rec.seckey}"/>

<input type="submit"
       value="Send Secret Key"
       class="btn btn-primary"/>

</form>

</td>

</tr>

</soham:forEach>

</table>

<%

if(usertype.equals("admin")){

%>

<%

}
else{

%>

<%

}

}
else{

%>

<h2>Invalid Session...Login again</h2>

<br>

<a href="index.jsp">Login</a>

<%

}

%>

</body>
</html>