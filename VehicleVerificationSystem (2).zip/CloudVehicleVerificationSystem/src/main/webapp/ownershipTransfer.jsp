<!DOCTYPE html>
<html>
<head>
    <title>Ownership Transfer</title>
</head>
<body>

<h2>Vehicle Ownership Transfer</h2>

<form action="saveTransfer" method="post">

    Vehicle ID:
    <input type="number" name="vehicleId" required>
    <br><br>

    Old Owner ID:
    <input type="number" name="oldOwnerId" required>
    <br><br>

    New Owner Name:
    <input type="text" name="newOwnerName" required>
    <br><br>

    Aadhaar Number:
    <input type="text" name="aadhaarNumber" maxlength="12" required>
    <br><br>

    <button type="submit">Submit Transfer</button>

</form>

<h3>${msg}</h3>

</body>
</html>