<!DOCTYPE html>
<html>
<head>
    <title>Aadhaar Verification</title>
</head>
<body>

<h2>Enter Aadhaar Number</h2>

<form action="verifyAadhaar" method="post">
    <input type="text" name="aadhaar" placeholder="Enter 12-digit Aadhaar" required>
    <br><br>
    <button type="submit">Verify</button>
</form>

<p>${msg}</p>

</body>
</html>