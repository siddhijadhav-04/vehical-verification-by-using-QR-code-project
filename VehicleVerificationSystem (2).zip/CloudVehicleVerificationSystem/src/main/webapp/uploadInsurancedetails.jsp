<%@page import="java.util.Vector"%>
<%@page import="models.JavaFuns"%>
<%@page import="beans.RandomString"%>
<%@page import="java.util.Date"%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insurance Details</title>
</head>

<body>

<jsp:include page="Top.jsp"></jsp:include>

<%
response.setHeader("Pragma", "No-cache");
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
response.setDateHeader("Expires", -1);

Date dt1=new Date();

String dt=(dt1.getDate())+"/"+(dt1.getMonth()+1)+"/"+(dt1.getYear()+1900);

String tm=dt1.getHours()+":"+dt1.getMinutes();

String seckey=RandomString.getAlphaNumericString(8);

JavaFuns jf=new JavaFuns();

Vector v=jf.getValue(
"select vid,vehicleName from vehicles where userid='"+
session.getAttribute("userid").toString().trim()+"'", 2);
%>

<div class="container">
<div class="row">

<div class="col-md-6">
<img src="images/insurance.png" width="70%"/>
</div>

<div class="col-md-6">

<div>

<center>
<h2>Insurance Details Storage</h2>
</center>

<br/>

<form id="frm"
      action="InsuranceReg"
      method="post"
      enctype="multipart/form-data">

<table class="tblform">

<tr>
<td>Insurance Company</td>

<td>
<input type="text"
       name="company"
       required
       class="form-control"/>
</td>
</tr>

<tr>
<td>Policy Number</td>

<td>
<input type="text"
       name="policyno"
       required
       class="form-control"/>
</td>
</tr>

<tr>
<td>Insurance Type</td>

<td>
<select name="instype"
        required
        class="form-control">

<option value="">--Select--</option>

<option value="Third Party">Third Party</option>

<option value="Comprehensive">Comprehensive</option>

</select>
</td>
</tr>

<tr>
<td>Start Date</td>

<td>
<input type="date"
       name="startdt"
       required
       class="form-control"/>
</td>
</tr>

<tr>
<td>Expiry Date</td>

<td>
<input type="date"
       name="expdt"
       required
       class="form-control"/>
</td>
</tr>

<tr>
<td>Vehicle</td>

<td>

<select name="vehicleid"
        required
        class="form-control">

<option value="">--Select Vehicle--</option>

<%for(int i=0;i<v.size();i=i+2){ %>

<option value="<%=v.elementAt(i).toString().trim()%>">

<%=v.elementAt(i+1).toString().trim()%>

</option>

<%} %>

</select>

</td>
</tr>

<tr>
<td>Insurance Amount</td>

<td>
<input type="text"
       name="amount"
       required
       class="form-control"/>
</td>
</tr>

<tr>
<td>Description</td>

<td>
<input type="text"
       name="description"
       required
       class="form-control"/>
</td>
</tr>

<tr>

<td>Insurance Document</td>

<td>

<input type="file"
       name="file"
       class="form-control"
       required>

<input type="hidden"
       name="userid"
       value="<%=session.getAttribute("userid").toString().trim()%>"/>

<input type="hidden"
       name="dt"
       value="<%=dt%>"/>

<input type="hidden"
       name="tm"
       value="<%=tm%>"/>

<input type="hidden"
       name="seckey"
       value="<%=seckey%>"/>

</td>
</tr>

<tr>

<td colspan="2">

<input type="submit"
       value="Save Insurance"
       class="btn btn-primary"/>

</td>

</tr>

</table>

</form>

</div>

</div>

</div>

</div>

</body>
</html>