<%@page import="models.States" %>
	<%@page import="java.util.List" %>
		<%@page import="models.GetStateNCities" %>
			<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
				<!DOCTYPE html>
				<html lang="en">

				<head>
					<title> Vehicle Verification By Using QR Code</title>
					<meta charset="utf-8">
					<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

					<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900"
						rel="stylesheet">
					<link
						href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i"
						rel="stylesheet">

					<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
					<link rel="stylesheet" href="css/animate.css">

					<link rel="stylesheet" href="css/owl.carousel.min.css">
					<link rel="stylesheet" href="css/owl.theme.default.min.css">
					<link rel="stylesheet" href="css/magnific-popup.css">

					<link rel="stylesheet" href="css/aos.css">

					<link rel="stylesheet" href="css/ionicons.min.css">

					<link rel="stylesheet" href="css/flaticon.css">
					<link rel="stylesheet" href="css/icomoon.css">
					<link rel="stylesheet" href="css/style.css">
					<style>

					</style>

					<script language="Javascript" type="text/javascript">


						function createRequestObject() {
							var tmpXmlHttpObject;
							if (window.XMLHttpRequest) {
								tmpXmlHttpObject = new XMLHttpRequest();
							} else if (window.ActiveXObject) {
								tmpXmlHttpObject = new ActiveXObject("Microsoft.XMLHTTP");
							}

							return tmpXmlHttpObject;
						}


						var http = createRequestObject();

						function makeGetRequest(st) {
							// st=document.frm.state.value;

							http.open('get', 'Cities?state=' + st);
							http.onreadystatechange = processResponse;
							http.send(null);
						}

						function processResponse() {
							if (http.readyState == 4) {
								var response = http.responseText;
								document.getElementById('cities').innerHTML = response;
							}
						}

					</script>
				</head>

				<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
					<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light site-navbar-target"
						id="ftco-navbar">
						<div class="container-fluid head">
							<div class="row">
								<div class="col-md- 4   ">
									<a class="navbar-brand" href="home">
										<h1 class="h1">Vehicle Verification By Using QR COde</h1>
									</a>
								</div>
								<div class="col-md-8">
									<button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button"
										data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav"
										aria-expanded="false" aria-label="Toggle navigation">
										<span class="oi oi-menu"></span> Menu
									</button>

									<div class="collapse navbar-collapse" id="ftco-nav">
										<ul class="navbar-nav nav ml-auto">
											<li class="nav-item"><a href="home" class="nav-link"><span>Home</span></a>
											</li>
											<li class="nav-item"><a href="#login"
													class="nav-link"><span>Login</span></a></li>

											<li class="nav-item"><a href="#services-section"
													class="nav-link"><span>Registration</span></a></li>
											<li class="nav-item"><a href="#about-section"
													class="nav-link"><span>About</span></a></li>


										</ul>
									</div>
								</div>
							</div>
						</div>
					</nav>

					<section id="home-section" class="hero">
						<img src="images/blob-shape-3.svg" class="svg-blob" alt="Colorlib Free Template">
						<div class="home-slider owl-carousel">
							<div class="slider-item">
								<div class="overlay"></div>
								<div class="container-fluid p-0">
									<div class="row d-md-flex no-gutters slider-text align-items-center justify-content-end"
										data-scrollax-parent="true">
										<div class="one-third order-md-last">
											<div class="img" style="background-image:url(images/banner.webp);">
												<div class="overlay"></div>
											</div>

										</div>
										<div class="one-forth d-flex align-items-center ftco-animate"
											data-scrollax=" properties: { translateY: '70%' }">
											<div class="text">
												<span class="subheading pl-5">Document Encryption</span>
												<h1 class="mb-4 mt-3">Secured Vehicle Document Storage on Cloud </h1>
												<p>Store your documents securely on cloud to avoid punishment from
													police due to missing documents</p>


											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="slider-item">
								<div class="overlay"></div>
								<div class="container-fluid p-0">
									<div class="row d-flex no-gutters slider-text align-items-center justify-content-end"
										data-scrollax-parent="true">
										<div class="one-third order-md-last">
											<div class="img" style="background-image:url(images/bg_1-1.jpg);">
												<div class="overlay"></div>
											</div>

										</div>
										<div class="one-forth d-flex align-items-center ftco-animate"
											data-scrollax=" properties: { translateY: '70%' }">
											<div class="text">
												<span class="subheading pl-5">Notification System</span>
												<h1 class="mb-4 mt-3">Automatic Notification for RTO documents
													Renewal</span></h1>
												<p>Register yourself and get automatic notification about RTO documents
													renewal to avoid punishment</p>


											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>



					<section class="ftco-section ftco-services-2" id="services-section">
						<div class="container">
							<div class="row justify-content-center pb-5">
								<div class="col-md-12 heading-section text-center ftco-animate">
									<span class="subheading"> New User</span>
									<h2 class="mb-4">Registration</h2>
									<div class="form-container" id="myDIV">
										<form name="frm" method="post" action="registeruser"
											enctype="multipart/form-data">
											<table class="tblform">
												<tr>
													<td>
														<table class="tblform">
															<tr>
																<td>
																	Userid</td>
																<td><input type="text" name="userid"
																		class="form-control" required></td>
															</tr>
															<tr>
																<td>User Name</td>
																<td><input type="text" name="usernm"
																		class="form-control" required></td>
															</tr>
															<tr>
																<td>Password</td>
																<td><input type="password" name="pswd"
																		class="form-control" required>
																	<input type="hidden" name="usertype" value="user" />
																</td>
															</tr>

															<tr>
																<td>Mobile Number</td>
																<td><input type="text" name="mobileno"
																		pattern="^\d{10}$" class="form-control"
																		required></td>
															</tr>
															<tr>
																<td>Email Address</td>
																<td><input type="text" name="emailid"
																		pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
																		class="form-control" required></td>
															</tr>
															<% GetStateNCities obj=new GetStateNCities();
																obj.getStates(); List<States> lst=obj.getLststate();
																%>
																<tr>
																	<td>State
																	</td>
																	<td>
																		<select required name="state"
																			class="form-control"
																			onchange="makeGetRequest(this.value)">
																			<option value=""><--select--></option>
																			<%for(int i=0;i<lst.size();i++) {%>
																				<option
																					value="<%=lst.get(i).getState() %>">
																					<%=lst.get(i).getState() %>
																				</option>
																				<%}%>
																		</select>
																	</td>
																</tr>
																<tr>
																	<td>City
																	</td>
																	<td>
																		<div id="cities"></div>
																	</td>
																</tr>
														</table>
													</td>
													<td>
														<table class="tblform">
															<tr>
																<td>Gender</td>
																<td>
																	<table class="tblform">
																		<tr>
																			<td>
																				<input type="hidden" name="userstatus"
																					value="active" />Male
																				<input type="radio" name="gender"
																					value="Male" checked="checked"
																					required>
																			</td>
																			<td>Female <input type="radio" name="gender"
																					value="Female" required>
																			</td>
																		</tr>
																	</table>
																</td>
															</tr>

															<tr>
																<td> Address</td>
																<td><textarea name="addr" class="form-control"
																		required></textarea></td>
															</tr>
															<tr>
																<td>Pincode</td>
																<td><input type="text" name="pincode"
																		class="form-control" required></td>
															</tr>

															<tr>
																<td>Date Of Birth</td>
																<td><input type="date" name="dob" class="form-control">
																</td>
															</tr>
															<tr>
																<td>Photo</td>
																<td>
																	<input type="file" name="file"
																		class="form-control" />
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td><input type="submit" value="Submit" class="btn btn-primary">
													</td>
												</tr>
											</table>
										</form>
									</div>

								</div>
							</div>
							<div class="row">

							</div>
						</div>
					</section>

					<section class="ftco-counter img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
						<div class="container">
							<div class="row no-gutters d-flex">
								<div class="col-md-6 col-lg-5 d-flex">
									<div class="img d-flex align-self-stretch align-items-center"
										style="background-image:url(images/banner2.webp);">
									</div>
								</div>
								<div class="col-md-6 col-lg-7 px-lg-5 py-md-5 bg-darken">
									<div class="py-md-5">
										<div class="row justify-content-start pb-3">
											<div class="col-md-12 heading-section ftco-animate p-5 p-lg-0">
												<span class="subheading">Welcome to Cloud based Vehicle Verification
													System</span>
												<h2 class="mb-4">About </h2>
												<p>The Vehicle Verification System Identification is an innovative
													solution designed to streamline and enhance vehicle verification
													processes. This system leverages cloud technology to provide a
													centralized platform for managing RTO offices, police operations,
													and user registrations. Key features include QR-based vehicle
													verification, AES algorithm implementation for secure document
													encryption and decryption, and a notification system to alert users
													about expiring RTO documents. </p>
												<p>The platform consists of dedicated modules for cloud administrators,
													RTO admins, RTO police, and vehicle owners, ensuring seamless
													collaboration and efficient management. By combining security,
													convenience, and automation, this system aims to modernize and
													simplify vehicle registration and verification procedures.</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>





					<section class="ftco-section testimony-section" id="login">
						<img src="images/blob-shape-2.svg" class="svg-blob" alt="Colorlib Free Template">
						<img src="images/blob-shape-2.svg" class="svg-blob-2" alt="Colorlib Free Template">
						<div class="container">
							<div class="row justify-content-center pb-3">
								<div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
									<span class="subheading"> </span>
									<h2 class="mb-4">Login</h2>
								</div>
							</div>
							<div class="row ftco-animate justify-content-center">
								<div class="col-md-12">
									<div class="jumbotron">
										<div class="row">
											<div class="col-md-6">
												<form name="frm" method="post" action="check">
													<table class="tblform">
														<tr>
															<td>Userid</td>
															<td>
																<input type="text" class="form-control" name="userid"
																	required>
															</td>
														</tr>
														<tr>
															<td>Password</td>
															<td> <input type="password" class="form-control" name="pswd"
																	required>
															</td>
														</tr>
														<tr>
															<td colspan="2"><input type="submit" class="btn btn-primary"
																	value="Submit"></td>
														</tr>
														<tr>
															<td colspan="2"><a href="forgetpassword"
																	class="black">Forget Password?</a></td>
														</tr>
													</table>
													<br /><br />


												</form>
											</div>
											<div class="col-md-6">
												<img src="images/login.gif" width="80%" />
											</div>
										</div>
									</div>
								</div>
							</div>
					</section>







					<footer class="ftco-footer ftco-section">
						<div class="container">

							<div class="row">
								<div class="col-md-12 text-center">

									<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
										<!-- Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved -->
										<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
									</p>
								</div>
							</div>
						</div>
					</footer>



					<!-- loader -->
					<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
							<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4"
								stroke="#eeeeee" />
							<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4"
								stroke-miterlimit="10" stroke="#F96D00" />
						</svg></div>


					<script src="js/jquery.min.js"></script>
					<script src="js/jquery-migrate-3.0.1.min.js"></script>
					<script src="js/popper.min.js"></script>
					<script src="js/bootstrap.min.js"></script>
					<script src="js/jquery.easing.1.3.js"></script>
					<script src="js/jquery.waypoints.min.js"></script>
					<script src="js/jquery.stellar.min.js"></script>
					<script src="js/owl.carousel.min.js"></script>
					<script src="js/jquery.magnific-popup.min.js"></script>
					<script src="js/aos.js"></script>
					<script src="js/jquery.animateNumber.min.js"></script>
					<script src="js/scrollax.min.js"></script>
					<script
						src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
					<script src="js/google-map.js"></script>

					<script src="js/main.js"></script>

				</body>

				</html>