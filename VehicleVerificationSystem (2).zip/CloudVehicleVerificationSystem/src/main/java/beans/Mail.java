/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

 
 

 
public class Mail {
	public boolean sendMail(String msg,String emailid,String sub,String filepath1)
    {
    	try {
			GMailer gobj=new GMailer(filepath1);
			gobj.sendMail(sub, msg, emailid); 
			return true;
			}
		 catch(Exception ex)
		 {
			 ex.printStackTrace();
			 return false;
		 }
 
    }
    
}
