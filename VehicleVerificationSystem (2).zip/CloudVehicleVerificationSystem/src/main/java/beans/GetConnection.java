package beans;

import java.sql.*;

public class GetConnection {

	private Connection dbconnection;
    public GetConnection()
    {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            
             dbconnection=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/defaultdb?user=root&password=root&useSSL=false&allowPublicKeyRetrieval=true");
           // dbconnection=DriverManager.getConnection("jdbc:mysql://avnadmin:AVNS_6d9Vue3m9Q4xP6nWBsd@mysql-e4386f-cloud-vehicle-verification.b.aivencloud.com:23062/defaultdb?ssl-mode=REQUIRED");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public Connection getConnection()
    {
        return(dbconnection);
    }
	
}
