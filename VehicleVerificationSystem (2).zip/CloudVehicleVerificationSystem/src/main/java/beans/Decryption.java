/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;

import javax.crypto.*;
import javax.crypto.spec.*;
import java.util.*;
 
public class Decryption {
    private String skey; 
    private int n,len;
     
    private int encsize;
    private double  encsizeAES,endtimeAES,enctimeAES,etimeAES,senctimeAES;
    public int getLen() {
        return len;
    } 
    
        public String getSkey() {
		return skey;
	}

	public void setSkey(String skey) {
		this.skey = skey;
	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	public int getEncsize() {
		return encsize;
	}

	public void setEncsize(int encsize) {
		this.encsize = encsize;
	}

	public double getEncsizeAES() {
		return encsizeAES;
	}

	public void setEncsizeAES(double encsizeAES) {
		this.encsizeAES = encsizeAES;
	}

	public double getEndtimeAES() {
		return endtimeAES;
	}

	public void setEndtimeAES(double endtimeAES) {
		this.endtimeAES = endtimeAES;
	}

	public double getEnctimeAES() {
		return enctimeAES;
	}

	public void setEnctimeAES(double enctimeAES) {
		this.enctimeAES = enctimeAES;
	}

	public double getEtimeAES() {
		return etimeAES;
	}

	public void setEtimeAES(double etimeAES) {
		this.etimeAES = etimeAES;
	}

	public double getSenctimeAES() {
		return senctimeAES;
	}

	public void setSenctimeAES(double senctimeAES) {
		this.senctimeAES = senctimeAES;
	}

	public void setLen(int len) {
		this.len = len;
	}

	public byte[] decryption(byte[] b )
    {
		 byte[] benc=null;
        try{
           
           // System.out.println("inputfile="+inFile);
        //  String[] ss=inFile.split("\\.");
         // String ext=ss[ss.length-1];
           //   byte[] b= Files.readAllBytes(Paths.get(inFile));
              
              
               benc=transformationAES(b,(skey));
                
                
              //FileOutputStream Fout=new FileOutputStream(outpath);
            //  Fout.write(benc);
             // Fout.flush();
           //   Fout.close();
              //encsizeAES=Double.parseDouble(String.valueOf(benc.length))/1024.0;
        }
        catch(Exception ex)
        {
           System.out.println("err="+ex.getMessage());
        }
        return benc;
         
    }
		 
		public static String getHash(File file) {
			try {
			 MessageDigest md = MessageDigest.getInstance("MD5");
	        synchronized (md) {
	            byte[] dataBytes = new byte[1024];

	            if (file != null && file.exists() && file.canRead() && file.isFile()) {
	                try (FileInputStream fis = new FileInputStream(file);) {
	                    md.reset();
	                    int nread = 0;
	                    while ((nread = fis.read(dataBytes)) != -1) {
	                        md.update(dataBytes, 0, nread);
	                    }
	                    ;
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }

	                byte[] mdbytes = md.digest();
	                Base64Encoder obj=new Base64Encoder();
	                return obj.encode(mdbytes);
	            } else {
	                return "NA";
	            }
	        }
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				 return "NA";
				 
			}
	    }
    
     public byte[] transformationAES(byte[] msg,String key)
{
    byte[] out=null;
    try{
        int cnt=0;
        byte[] keyb=key.getBytes();
        AESencrp.setKeyValue(keyb);
         senctimeAES=System.nanoTime();
        out=AESencrp.decryptB(msg);
         endtimeAES=System.nanoTime();
         etimeAES=endtimeAES-senctimeAES;
    }
    catch(Exception ex)
    {
        System.out.println("error in transformation="+ex.getMessage());
    }
    return out;
}
     
  
    
}
