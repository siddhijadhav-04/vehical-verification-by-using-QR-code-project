package beans; 

import java.io.FileOutputStream;

public class QRCodeGenerator {
	  

	  // Function to generate QR Code
    public static void generateQRCode(String data, String filePath, int width, int height) throws Exception {
        // Use ZXing to generate QR code
        com.google.zxing.qrcode.QRCodeWriter qrCodeWriter = new com.google.zxing.qrcode.QRCodeWriter();
        com.google.zxing.common.BitMatrix bitMatrix = qrCodeWriter.encode(data, com.google.zxing.BarcodeFormat.QR_CODE, width, height);

        java.nio.file.Path path = java.nio.file.FileSystems.getDefault().getPath(filePath);
        com.google.zxing.client.j2se.MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
    }

    
}

