package beans;

public class GetURL {
	public static String getPythonServerURL()
	{
		return "http://127.0.0.1:8000/";
	}
	 
}
