package beans;

public class IPAddress {
public static String getIP()
{
	return "10.103.241.189";
}
}
