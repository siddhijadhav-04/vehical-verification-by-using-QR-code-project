package models;
import java.sql.*;
import java.util.List;
import java.util.Vector;

import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import beans.GetConnection;
 
public class CheckUser {

	private String userid,utype;
	private String pswd;
	Connection con;
	public String getUtype() {
		return utype;
	}
	public void setUtype(String utype) {
		this.utype = utype;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	
	public String checkUser(HttpServletRequest request) {
		
		 
		ResultSet rs;
		String typ="failure",st="LoginFailure.jsp";
		GetConnection gc = new GetConnection();
		
		
		try {
			
			
			con=gc.getConnection();
			PreparedStatement pst;
			pst=con.prepareStatement("select * from users where userid=? and pswd=? and userstatus='active' ");
			pst.setString(1,userid );
			pst.setString(2, pswd);
				
			rs=pst.executeQuery();
			
			if(rs.next()) {
					System.out.println("in rs");			
				JavaFuns jf=new JavaFuns();
				String qr="";
				typ=rs.getString("usertype");
				utype=typ;
				HttpSession sess=request.getSession(true);
				sess.setAttribute("usertype", rs.getString("usertype"));
				sess.setAttribute("usernm", rs.getString("usernm"));
				utype=rs.getString("usertype");
				System.out.println("typ="+typ);
				try {
					con.close();
				}
				catch (Exception e) {
					// TODO: handle exception
				}
				
				sess.setAttribute("userid",userid);
				 
				
				sess.setAttribute("photo", getPhoto(userid, typ));
				System.out.println("type="+typ);
				LoginTracker lt=new LoginTracker();
				lt.recordLogin(userid, typ);
				if(typ.equals("officer"))
					st="officer";
				else if(typ.equals("user"))
				{
					 
					 
					st="user";
				}
				else if(typ.equals("cloudadmin"))
					st="cloudadmin";
				else if(typ.equals("police"))
					st="police";
				 
			}
			else
			{
				st="LoginFailure.jsp";
				utype="NA";
			}
		}
		
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally
		{
			try {con.close();}catch (Exception e) {}
		}
		return(st);	
	}
public String getPhoto(String userid,String utype) {
		String photo="common.png";
		 
		ResultSet rs;
		String typ,st="";
		GetConnection gc = new GetConnection();
		
		
		try {
			
			
			con=gc.getConnection();
			PreparedStatement pst;
			String qr="";
			if(utype.equals("user"))
			{
				qr="select photo from userdetails where userid='"+userid+"'";
			}
			else
				qr="select photo from offices where userid='"+userid+"'";

			pst=con.prepareStatement(qr);
			 
			rs=pst.executeQuery();
			
			if(rs.next()) { 
				photo=rs.getString("photo");
				 
			}
			try {
				con.close();
			}
			catch (Exception e) {
				// TODO: handle exception
			} 
		}
		
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally
		{
			try {con.close();}catch (Exception e) {}
		}
		return(photo);	
	}
}
