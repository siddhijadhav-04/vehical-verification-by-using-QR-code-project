package models;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import beans.GetConnection;

public class InsuranceDetails {

private int id, vehicleid;

private String userid, company, policyno,
instype, startdt, expdt,
amount, description,status,
filePath, seckey,
sts, dt, tm;

private MultipartFile file;

private List<InsuranceDetails> lst;

Connection con;
CallableStatement csmt;
ResultSet rs;


// ================= GETTER SETTER =================

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getVehicleid() {
	return vehicleid;
}

public void setVehicleid(int vehicleid) {
	this.vehicleid = vehicleid;
}

public String getUserid() {
	return userid;
}

public void setUserid(String userid) {
	this.userid = userid;
}

public String getCompany() {
	return company;
}

public void setCompany(String company) {
	this.company = company;
}

public String getPolicyno() {
	return policyno;
}

public void setPolicyno(String policyno) {
	this.policyno = policyno;
}

public String getInstype() {
	return instype;
}

public void setInstype(String instype) {
	this.instype = instype;
}

public String getStartdt() {
	return startdt;
}

public void setStartdt(String startdt) {
	this.startdt = startdt;
}

public String getExpdt() {
	return expdt;
}

public void setExpdt(String expdt) {
	this.expdt = expdt;
}

public String getAmount() {
	return amount;
}

public void setAmount(String amount) {
	this.amount = amount;
}

public String getDescription() {
	return description;
}

public void setStatus(String status) {
	this.status = status;
}

public String getStatus() {
	return status;
}

public void setDescription(String description) {
	this.description = description;
}

public String getFilePath() {
	return filePath;
}

public void setFilePath(String filePath) {
	this.filePath = filePath;
}

public String getSeckey() {
	return seckey;
}

public void setSeckey(String seckey) {
	this.seckey = seckey;
}

public String getSts() {
	return sts;
}

public void setSts(String sts) {
	this.sts = sts;
}

public String getDt() {
	return dt;
}

public void setDt(String dt) {
	this.dt = dt;
}

public String getTm() {
	return tm;
}

public void setTm(String tm) {
	this.tm = tm;
}

public MultipartFile getFile() {
	return file;
}

public void setFile(MultipartFile file) {
	this.file = file;
}

public List<InsuranceDetails> getLst() {
	return lst;
}

public void setLst(List<InsuranceDetails> lst) {
	this.lst = lst;
}


// ================= INSERT =================

//================= INSERT =================

public String insertInsurance() {

	String st = "failure";

	try {

		GetConnection obj = new GetConnection();

		con = obj.getConnection();

		CallableStatement cst =
		con.prepareCall("{call insertInsurance(?,?,?,?,?,?,?,?,?,?,?,?,?)}");

		cst.setString(1, userid);

		cst.setString(2, company);

		cst.setString(3, policyno);

		cst.setString(4, instype);

		cst.setString(5, startdt);

		cst.setString(6, expdt);

		cst.setString(7, amount);

		cst.setString(8, description);
		
		cst.setString(9, status);

		cst.setString(9, filePath);

		cst.setString(10, seckey);

		cst.setString(11, dt);

		cst.setString(12, tm);

		cst.setInt(13, vehicleid);

		int x = cst.executeUpdate();

		if(x > 0)
		{
			st = "success";
		}
		else
		{
			st = "failure";
		}

	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
	finally
	{
		try
		{
			con.close();
		}
		catch(Exception e){}
	}

	return st;
}


// ================= RESULTSET CONSTRUCTOR =================

//================= RESULTSET CONSTRUCTOR =================

public InsuranceDetails(ResultSet rs)
{
	try
	{
		id = rs.getInt("id");

		company = rs.getString("company");

		policyno = rs.getString("policy_no");

		instype = rs.getString("insurance_type");

		startdt = rs.getString("start_date");

		expdt = rs.getString("expiry_date");

		amount = rs.getString("amount");

		description = rs.getString("description");
         
		status = rs.getString("status");

		filePath = rs.getString("document");

		seckey = rs.getString("secret_key");

		userid = rs.getString("userid");

		vehicleid = rs.getInt("vehicle_id");

		dt = rs.getString("upload_date");

		tm = rs.getString("upload_time");
	}
	catch(Exception e)
	{
		System.out.println("err="+e.getMessage());
	}
}

// ================= DEFAULT CONSTRUCTOR =================

public InsuranceDetails()
{

}


// ================= VIEW INSURANCE =================

public void getInsuranceDetails(String userid)
{
	lst = new ArrayList<InsuranceDetails>();

	try
	{
		GetConnection obj = new GetConnection();

		con = obj.getConnection();

		csmt = con.prepareCall("{call getInsurance(?)}");

		csmt.setString(1, userid);

		csmt.execute();

		rs = csmt.getResultSet();

		while(rs.next())
		{
			lst.add(new InsuranceDetails(rs));
		}

	}
	catch(Exception ex)
	{
		System.out.println("err="+ex.getMessage());
	}
	finally
	{
		try
		{
			con.close();
		}
		catch(Exception e){}
	}
}

}