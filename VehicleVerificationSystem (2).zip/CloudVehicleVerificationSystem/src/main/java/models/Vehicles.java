package models;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import org.springframework.web.multipart.MultipartFile;

import beans.GetConnection;

public class Vehicles {
	private String userid,ownerName,licenseNo,vehicleType,sts;
	private String city,dt;
	private String state;
	private String usernm,seckey;
	private String vehicleName;
	private String company;
	private String details;
	private String chesisNo;
	private String engineNo;
	private MultipartFile file;
	private String path;
	private int vid;
	Connection con;
public int getVid() {
		return vid;
	}

	public String getSeckey() {
	return seckey;
}

public void setSeckey(String seckey) {
	this.seckey = seckey;
}

	public void setVid(int vid) {
		this.vid = vid;
	}

public String getSts() {
		return sts;
	}

	public void setSts(String sts) {
		this.sts = sts;
	}

public String getDt() {
		return dt;
	}

	public void setDt(String dt) {
		this.dt = dt;
	}

public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUsernm() {
		return usernm;
	}

	public void setUsernm(String usernm) {
		this.usernm = usernm;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getChesisNo() {
		return chesisNo;
	}

	public void setChesisNo(String chesisNo) {
		this.chesisNo = chesisNo;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
public List<Vehicles> getVehicleDetails1(String txt){
		
		GetConnection gc = new GetConnection();
		 
		List<Vehicles> lst = new ArrayList<Vehicles>();
		System.out.println("userid="+txt);
		ResultSet rs;
		
		try {
		
		con= gc.getConnection();
		Statement st=con.createStatement();
		String[] str=txt.split("\\|");
		
		
		//String qr="SELECT *,  MATCH(licenseNo)  AGAINST('"+txt.trim()+"' IN NATURAL LANGUAGE MODE)  AS score FROM vehicles WHERE   MATCH(licenseNo)   AGAINST('"+txt.trim()+"' IN NATURAL LANGUAGE MODE);";
		String qr="SELECT *  FROM vehicles WHERE   ";
		for(int i=0;i<str.length;i++)
		{
			if(i==0)
				qr+=" MATCH(licenseNo)   AGAINST('"+str[i].trim()+"' IN NATURAL LANGUAGE MODE)";
			else
				qr+=" or MATCH(licenseNo)   AGAINST('"+str[i].trim()+"' IN NATURAL LANGUAGE MODE)";
		}
		rs=st.executeQuery(qr);
		System.out.println("qr="+qr);
		Vehicles vs;
		 
		while(rs.next()) {
			
			vs= new Vehicles();
			vs.setUserid(rs.getString("userid"));
			vs.setUsernm(rs.getString("usernm"));
			vs.setVehicleName(rs.getString("vehicleName"));
			vs.setChesisNo(rs.getString("chesisNo"));
			vs.setEngineNo(rs.getString("engineNo"));
			//vs.setCompany(rs.getString("company"));
			vs.setDetails(rs.getString("details"));;
			vs.setLicenseNo(rs.getString("licenseNo"));
			vs.setDt(rs.getString("dt"));
			vs.setOwnerName(rs.getString("ownerName"));
			vs.setPath(rs.getString("vehicledocs"));
			vs.setState(rs.getString("state"));
			vs.setCity(rs.getString("city"));
			vs.setSts(rs.getString("sts"));
			vs.setVehicleType(rs.getString("vehicleType"));
			lst.add(vs);
		}
		
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally
		{
			try {con.close();}catch (Exception e) {}
		}
		return(lst);
	}
	 
public List<Vehicles> getVehicleDetails(String userid1){
		
		GetConnection gc = new GetConnection();
		 
		List<Vehicles> lst = new ArrayList<Vehicles>();
		System.out.println("userid="+userid1);
		ResultSet rs;
		
		try {
		
		con= gc.getConnection();
		Statement st=con.createStatement();
		rs=st.executeQuery("select *,aes_decrypt(skey,vid) as skey1 from vehicles where userid='"+userid1+"'");
		Vehicles vs;
		 
		while(rs.next()) {
			
			vs= new Vehicles();
			vs.setVid(rs.getInt("vid"));
			vs.setUserid(rs.getString("userid"));
			vs.setUsernm(rs.getString("usernm"));
			vs.setVehicleName(rs.getString("vehicleName"));
			vs.setChesisNo(rs.getString("chesisNo"));
			vs.setEngineNo(rs.getString("engineNo"));
			//vs.setCompany(rs.getString("company"));
			vs.setDetails(rs.getString("details"));;
			vs.setLicenseNo(rs.getString("licenseNo"));
			vs.setDt(rs.getString("dt"));
			vs.setOwnerName(rs.getString("ownerName"));
			vs.setPath(rs.getString("vehicledocs"));
			vs.setState(rs.getString("state"));
			vs.setCity(rs.getString("city"));
			vs.setSts(rs.getString("sts"));
			vs.setVehicleType(rs.getString("vehicleType"));
			vs.setSeckey(rs.getString("skey1"));
			lst.add(vs);
		}
		
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally
		{
			try {con.close();}catch (Exception e) {}
		}
		return(lst);
	}
public List<Vehicles> getVehicleDetails12(int count){
	
	GetConnection gc = new GetConnection();
	 
	List<Vehicles> lst = new ArrayList<Vehicles>();
	 
	ResultSet rs;
	
	try {
	
	con= gc.getConnection();
	Statement st=con.createStatement();
	String qr="";
	JavaFuns jf=new JavaFuns();
	Vector v=jf.getValue("select noplate from highspeedvehicles", 1);
	for(int i=0;i<v.size();i++)
	{
		if(qr.equals(""))
			qr="select * from vehicles where licenseNo regexp ('"+v.elementAt(i).toString().trim()+"')";
		else
			qr=" union select * from vehicles where licenseNo regexp ('"+v.elementAt(i).toString().trim()+"')";
	}
	
	rs=st.executeQuery(qr);
	Vehicles vs;
	 
	while(rs.next()) {
		
		vs= new Vehicles();
		vs.setUserid(rs.getString("userid"));
		vs.setUsernm(rs.getString("usernm"));
		vs.setVehicleName(rs.getString("vehicleName"));
		vs.setChesisNo(rs.getString("chesisNo"));
		vs.setEngineNo(rs.getString("engineNo"));
		//vs.setCompany(rs.getString("company"));
		vs.setDetails(rs.getString("details"));;
		vs.setLicenseNo(rs.getString("licenseNo"));
		vs.setDt(rs.getString("dt"));
		vs.setOwnerName(rs.getString("ownerName"));
		vs.setPath(rs.getString("vehicledocs"));
		vs.setState(rs.getString("state"));
		vs.setCity(rs.getString("city"));
		vs.setSts(rs.getString("sts"));
		vs.setVid(rs.getInt("vid"));
		vs.setVehicleType(rs.getString("vehicleType"));
		lst.add(vs);
	}
	
	}
	catch(Exception ex){
		ex.printStackTrace();
	}
	finally
	{
		try {con.close();}catch (Exception e) {}
	}
	return(lst);
}
public List<Vehicles> getVehicleDetails11(String userid1){
	
	GetConnection gc = new GetConnection();
	 
	List<Vehicles> lst = new ArrayList<Vehicles>();
	System.out.println("userid="+userid1);
	ResultSet rs;
	
	try {
	
	con= gc.getConnection();
	Statement st=con.createStatement();
	rs=st.executeQuery("select *,aes_decrypt(skey,vid) as skey1 from vehicles where sts='pending' and city in (select city from   offices where userid='"+userid1+"')");
	System.out.println("select *,aes_decrypt(skey,vid) as skey1 from vehicles where sts='pending' and city in (select city from   offices where userid='"+userid1+"')");
	Vehicles vs;
	 
	while(rs.next()) {
		
		vs= new Vehicles();
		vs.setUserid(rs.getString("userid"));
		vs.setUsernm(rs.getString("usernm"));
		vs.setVehicleName(rs.getString("vehicleName"));
		vs.setChesisNo(rs.getString("chesisNo"));
		vs.setEngineNo(rs.getString("engineNo"));
		//vs.setCompany(rs.getString("company"));
		vs.setDetails(rs.getString("details"));;
		vs.setLicenseNo(rs.getString("licenseNo"));
		vs.setDt(rs.getString("dt"));
		vs.setOwnerName(rs.getString("ownerName"));
		vs.setPath(rs.getString("vehicledocs"));
		vs.setState(rs.getString("state"));
		vs.setCity(rs.getString("city"));
		vs.setSts(rs.getString("sts"));
		vs.setSeckey(rs.getString("skey1"));
		vs.setVid(rs.getInt("vid"));
		vs.setVehicleType(rs.getString("vehicleType"));
		lst.add(vs);
	}
	
	}
	catch(Exception ex){
		ex.printStackTrace();
	}
	finally
	{
		try {con.close();}catch (Exception e) {}
	}
	return(lst);
} 
public int getId()
{
		int mxid=0;
    try
    {Connection con;
	PreparedStatement pst;
	GetConnection gc = new GetConnection();
	
         
        con=gc.getConnection();
      CallableStatement csmt=con.prepareCall("{call getMaxIdVehicles()}");
       
         csmt.execute();
        ResultSet rs=csmt.getResultSet();
                    
        boolean auth=false;
        while(rs.next())
        { System.out.println("true");
            auth=true;
            
            mxid=rs.getInt("mxid");
              
        }
        try {con.close();}catch (Exception e) {}
    }
       
     
    catch(Exception ex)
    {
        System.out.println("err="+ex.getMessage());
         
    }
    finally
	{
		try {con.close();}catch (Exception e) {}
	}
    return mxid+1;
} 
	public String addVehicles()
	{
		GetConnection gc = new GetConnection();
		int y=0;
		
		int id=0;
		String st="";
		try {
			id=getId();
		con=gc.getConnection();
		PreparedStatement pst;
		
		pst=con.prepareStatement("insert into vehicles values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,AES_ENCRYPT(?,?));");

		pst.setInt(1,id);
		pst.setString(2,vehicleName);
		pst.setString(3,ownerName);
		pst.setString(4,vehicleType);
		pst.setString(5,chesisNo); 
		pst.setString(6,engineNo);
		pst.setString(7,userid); 
		pst.setString(8,usernm); 
		pst.setString(9,details);
		Date dt1=new Date();
		String dt=dt1.getDate()+"/"+(dt1.getMonth()+1)+"/"+(dt1.getYear()+1900);
		pst.setString(10,dt);
		pst.setString(11,state); 
		pst.setString(12,city);
		pst.setString(13,licenseNo);
		pst.setString(14,path); 
		pst.setString(15,"pending"); 
		pst.setString(16,seckey); 
		pst.setString(17,String.valueOf(id));
		int x=pst.executeUpdate();
		
		if(x>0) {
			
			st="success";
		}
		else
			st="failure";
		  
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally
		{
			try {con.close();}catch (Exception e) {}
		}
		return st;
		
		
	} 

}
