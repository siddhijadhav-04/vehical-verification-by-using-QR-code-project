package models;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
 
public class Regex5Digits
{
    public static final Pattern PAT = Pattern.compile( "\\b(\\d{6}[^\\s]*)" );
     public List<String> lstpin;
     
    //static String good = "12345 55555q 666666*&^ 77777\t 88888*123\t\n12345";
   // static String bad  = "1234 q1234 123&*(456 123\n456 whole word buz12345";
     
    public List<String> getLstpin() {
		return lstpin;
	}

	public void setLstpin(List<String> lstpin) {
		this.lstpin = lstpin;
	}

	public void main( String str)
    {
        Matcher         m;
        //int             cnt;
        lstpin=new ArrayList<String>(); 
      //  System.out.println( "GOOD:" );
        m = PAT.matcher( str );
        //cnt = 0;
        while( m.find() )
        {
            System.out.println( "\"" + m.group(1) + "\"" );
            lstpin.add(m.group(1));
          //  cnt++;
        }
        /* if( cnt != 6 )
            System.out.println( "Expecting 6 matches and found " + cnt );
         
        System.out.println();
        System.out.println( "BAD:" );
        m = PAT.matcher( bad );
        cnt = 0;
        while( m.find() )
        {
            System.out.println( "\"" + m.group(1) + "\"" );
            cnt++;
        }
        if( cnt != 0 )
            System.out.println( "Expecting 0 matches and found " + cnt );*/
    }
}