package models;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.springframework.web.multipart.MultipartFile;

import beans.CloudFuns;
import beans.GetConnection;
 

public class Documents {
private String userid,dhash,expdt,sts,seckey2,username,seckey,otp,uotp,title,docdesc,dt,tm,filePath;
private List<Documents> lst;
private MultipartFile file;
private int vehicleid,docid;
Connection con;
CallableStatement csmt;
ResultSet rs;
 
public String getSts() {
	return sts;
}

public void setSts(String sts) {
	this.sts = sts;
}

public int getVehicleid() {
	return vehicleid;
}

public String getExpdt() {
	return expdt;
}

public void setExpdt(String expdt) {
	this.expdt = expdt;
}

public void setDocid(int docid) {
	this.docid = docid;
}

public void setVehicleid(int vehicleid) {
	this.vehicleid = vehicleid;
}

public String getSeckey2() {
	return seckey2;
}

public void setSeckey2(String seckey2) {
	this.seckey2 = seckey2;
}

public MultipartFile getFile() {
	return file;
}

public void setFile(MultipartFile file) {
	this.file = file;
}

public String getDhash() {
	return dhash;
}

public void setDhash(String dhash) {
	this.dhash = dhash;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public List<Documents> getLst() {
	return lst;
}

public void setLst(List<Documents> lst) {
	this.lst = lst;
}

public String getOtp() {
	return otp;
}

public void setOtp(String otp) {
	this.otp = otp;
}

public String getUotp() {
	return uotp;
}

public void setUotp(String uotp) {
	this.uotp = uotp;
}

public String getSeckey() {
	return seckey;
}

public void setSeckey(String seckey) {
	this.seckey = seckey;
}
 
public String getUserid() {
	return userid;
}

public void setUserid(String userid) {
	this.userid = userid;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getDocdesc() {
	return docdesc;
}

public void setDocdesc(String docdesc) {
	this.docdesc = docdesc;
}

public String getDt() {
	return dt;
}

public void setDt(String dt) {
	this.dt = dt;
}

public int getDocid() {
	return docid;
}

public String getTm() {
	return tm;
}

public void setTm(String tm) {
	this.tm = tm;
}

public String getFilePath() {
	return filePath;
}

public void setFilePath(String filePath) {
	this.filePath = filePath;
}
public Documents()
{
	
}
public String insert()
{	String st="failure";
	try
	{
	 
	int y=0;
	  System.out.println("vehicle id="+vehicleid);
	CallableStatement cst;
	GetConnection obj=new  GetConnection();
    con=obj.getConnection();
    cst=con.prepareCall("{call insertDoc(?,?,?,?,?,?,?,?,?,?,?)}");
    
   cst.setInt(1, docid);
   cst.setString(2, userid);
   cst.setString(3, title);
   cst.setString(4, dt);
   cst.setString(5, tm);
   cst.setString(6, docdesc);
   cst.setString(7, seckey);
   
   cst.setString(8, filePath);
   cst.setString(9, "NA");
   cst.setInt(10, vehicleid);
   cst.setString(11, expdt);
    int x= cst.executeUpdate();
	 
	if(x>0) {
		
		st="success";
	}
	else
		st="failure";
	
	 
	try
	{
		con.close();
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	 
	}
	catch(Exception ex) {
		ex.printStackTrace();
	}
	finally
	{
		try
		{
			con.close();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	return st;
	
	
}
public Documents(ResultSet rs)
{
	try
	{docid=rs.getInt("docid");
	System.out.println("docid="+docid);
		title=rs.getString("title").trim();
		seckey=rs.getString("skey").trim();
   	 dt=rs.getString("dt").trim();
   	 tm=rs.getString("tm").trim();
   	 docdesc=rs.getString("docdesc").trim();
   	dhash=rs.getString("dhash").trim();
   	 filePath=rs.getString("filePath").trim();
 	userid=rs.getString("userid").trim();
   	username=rs.getString("usernm").trim();
   	expdt=rs.getString("expdt").trim();
   	sts=rs.getString("sts").trim();
	}
	catch (Exception e) {
		// TODO: handle exception
		System.out.println("err="+e.getMessage());
	}
}
public void getPendingDocs(String userid)
{
	boolean flag=false;
	  lst=new ArrayList<Documents>();
    try
    {
         GetConnection  obj=new  GetConnection();
         
        con=obj.getConnection();
        csmt=con.prepareCall("{call getDocuments2(?)}");
         
        csmt.setString(1, userid);
        
         csmt.execute();
         rs=csmt.getResultSet();
                     
        while(rs.next())
        {  
        	lst.add(new Documents(rs));
        }
    }
       
     
    catch(Exception ex)
    {
        System.out.println("err in api="+ex.getMessage());
         
    }
    finally
	{
		try
		{
			con.close();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
    
}
public void getDocs12(String vid)
{
	boolean flag=false;
	  lst=new ArrayList<Documents>();
    try
    {
    	JavaFuns jf=new JavaFuns();
    	Vector v=jf.getValue("select userid from vehicles where vid="+vid.trim(), 1);
    	String userid=v.elementAt(0).toString().trim();
         GetConnection  obj=new  GetConnection();
         
        con=obj.getConnection();
        csmt=con.prepareCall("{call getDocuments1(?)}");
         
        csmt.setString(1, userid);
        
         csmt.execute();
         rs=csmt.getResultSet();
                     
        while(rs.next())
        {  
        	lst.add(new Documents(rs));
        }
    }
       
     
    catch(Exception ex)
    {
        System.out.println("err in api="+ex.getMessage());
         
    }
    finally
	{
		try
		{
			con.close();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
    
}
public void getDocs(String userid)
{
	boolean flag=false;
	  lst=new ArrayList<Documents>();
    try
    {
         GetConnection  obj=new  GetConnection();
         
        con=obj.getConnection();
        csmt=con.prepareCall("{call getDocuments1(?)}");
         
        csmt.setString(1, userid);
        
         csmt.execute();
         rs=csmt.getResultSet();
                     
        while(rs.next())
        {  
        	lst.add(new Documents(rs));
        }
    }
       
     
    catch(Exception ex)
    {
        System.out.println("err in api="+ex.getMessage());
         
    }
    finally
	{
		try
		{
			con.close();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
    
}
public void getUserDocs(String docids)
{
	boolean flag=false;
  lst=new ArrayList<Documents>();
    try
    {
        GetConnection obj=new  GetConnection();
         
        con=obj.getConnection();
        Statement st=con.createStatement();
        System.out.println("qr="+"select * from getdocuments where  docid in("+docids+")");
		rs=st.executeQuery("select * from getdocuments where  docid in("+docids+")");
                     
        while(rs.next())
        {  
        	lst.add(new Documents(rs));
        }
    } 
    catch(Exception ex)
    {
        System.out.println("err in api="+ex.getMessage());
         
    }
    finally
	{
		try
		{
			con.close();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
     
}
}
