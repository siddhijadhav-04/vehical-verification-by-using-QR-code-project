package com.cloud.vehicle.verification;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import jakarta.servlet.ServletRequest;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.boot.system.ApplicationTemp;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import beans.Base64Decoder;
import beans.Base64Encoder;
import beans.CloudFuns;
import beans.Decryption;
import beans.Encryption;
import beans.GMailer;
import beans.IPAddress;
import beans.Mail;
import beans.QRCodeGenerator;
import beans.RandomString; 
import models.CheckUser;
import models.Documents;
import models.InsuranceDetails;
import models.JavaFuns;
import models.Offices;
import models.Pass;
import models.PasswordRecovery;
 
import models.Users;
import models.Vehicles;
import models.ViewOffice;
 
 

@Controller
public class CloudController implements ErrorController{
	
	@RequestMapping("/verify")
	public String verify(HttpServletRequest request)
	{
		return "verify.jsp";
	}
	@RequestMapping("/home")
	public String index(HttpServletRequest request)
	{
		JavaFuns jf=new JavaFuns();
		String qr="";
		String filepath1=request.getServletContext().getRealPath("/");
		qr="SELECT title,d.userid,u.emailid,expdt,d.docid FROM documents  d inner join userdetails u  on d.userid=u.userid  "
				+ "WHERE sts='approved' and (STR_TO_DATE(expdt, '%Y-%m-%d') = CURDATE() "
				+ "   OR STR_TO_DATE(expdt, '%Y-%m-%d') = DATE_ADD(CURDATE(), INTERVAL 1 DAY));";
		Vector v=jf.getValue(qr, 5);
		try {
			for(int i=0;i<v.size();i=i+5)
			{
				String title=v.elementAt(i).toString().trim();
				String expdt=v.elementAt(i+3).toString().trim();
				String msg="Dear "+v.elementAt(i+1).toString().trim()+", your document is about to expire. Expiry date of document having title "+title+"is "+expdt;
				GMailer gmail=new GMailer(filepath1);
				if(gmail.sendMail("Document Expiry Notification",msg , v.elementAt(i+2).toString().trim())){
					if(jf.execute("update documents set sts='Notified' where docid="+v.elementAt(i+4).toString().trim())) {}
					
				}
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return "index.jsp";
	}
	@RequestMapping("/approveVehicle")
	public ModelAndView approveVehicle(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Success.jsp");
		mv.addObject("activity","vehicleApproved");
		JavaFuns jf=new JavaFuns();
		if(jf.execute("update vehicles set sts='approved' where vid="+request.getParameter("vid").trim())) {}
		return mv;
	}
	@RequestMapping("/approvedoc")
	public ModelAndView approvedoc(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Success.jsp");
		mv.addObject("activity","docsApproved");
		JavaFuns jf=new JavaFuns();
		if(jf.execute("update documents set sts='approved' where docid="+request.getParameter("docid").trim())) {}
		return mv;
	}
	@RequestMapping("/Cities")
	public String cities()
	{
		return "Cities.jsp";
	}
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
        session.invalidate();
		return "Logout.jsp";
	}
	@RequestMapping("/regOffice")
	public String registration()
	{
		return "Register.jsp";
	}
	@RequestMapping("/regOffice1")
	public String registration11()
	{
		return "Register1.jsp";
	}
	@RequestMapping("/user")
	public String student()
	{
		return "User.jsp";
	}
	
	
	@RequestMapping("/insurance")
	public String insurancePage() {
	    return "uploadInsurancedetails.jsp";
	}
	
	  
	@RequestMapping("/uploaddoc")
	public String uploaddoc()
	{
		return "UploadDocs.jsp";
	}
	@RequestMapping("/getPendingDocs")
	@SessionScope
	public ModelAndView getPendingDocs(HttpSession ses) {
		ModelAndView mv=new ModelAndView();
		try
		{
		List<models.Documents> lst = new ArrayList<Documents>();
		//CallMinnerAPI vs = new CallMinnerAPI();
		Documents obj=new Documents();
		 
		  obj.getPendingDocs(ses.getAttribute("userid").toString().trim());
		
		mv.addObject("std",obj.getLst());
		mv.setViewName("ViewDocs.jsp");
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("err="+e.getMessage());
		}
		return mv;
	}
	@RequestMapping("/viewdocs")
	@SessionScope
	public ModelAndView viewMyDocs(HttpSession ses) {
		ModelAndView mv=new ModelAndView();
		try
		{
		List<models.Documents> lst = new ArrayList<Documents>();
		//CallMinnerAPI vs = new CallMinnerAPI();
		Documents obj=new Documents();
		 
		  obj.getDocs(ses.getAttribute("userid").toString().trim());
		
		mv.addObject("std",obj.getLst());
		mv.setViewName("ViewMyDocs.jsp");
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("err="+e.getMessage());
		}
		return mv;
	}
	
	
	@RequestMapping("/viewinsurance")
	@SessionScope
	public ModelAndView viewInsurance(HttpSession ses) {

	    ModelAndView mv = new ModelAndView();

	    try
	    {

	        List<models.InsuranceDetails> lst =
	                new ArrayList<models.InsuranceDetails>();

	        InsuranceDetails obj = new InsuranceDetails();

	        obj.getInsuranceDetails(
	                ses.getAttribute("userid")
	                .toString()
	                .trim());

	        mv.addObject("std", obj.getLst());

	        mv.setViewName("viewinsurancedetails.jsp");

	    }
	    catch (Exception e)
	    {
	        System.out.println("err=" + e.getMessage());
	    }

	    return mv;
	}
	
	
	@SessionScope
	@RequestMapping("/sendOTPPolice")
	public ModelAndView sendOTPPolice( HttpServletRequest request,HttpSession ses)
	{
	 ModelAndView mv=new ModelAndView();
	 
		 try {
			 
			 String otp= beans.RandomString.getAlphaNumericString(4);
			    mv.setViewName("OTPVerificationPolice.jsp");
			    
				mv.addObject("otp",otp);
				Mail mail=new   Mail();
				System.out.println("otp="+otp);
				CloudFuns jf=new CloudFuns();
				String qr="select emailid,usernm from userdetails where userid=(select userid from vehicles where vid="+ses.getAttribute("vid").toString().trim()+")";
				Vector v=jf.getValue(qr, 2);
				ses.setAttribute("username", v.elementAt(1).toString().trim());
				ses.setAttribute("email", v.elementAt(0).toString().trim());
				String msg="Dear "+ses.getAttribute("username").toString().trim()+", your one time password is "+otp;
				
				try
				{
					String filepath1=request.getServletContext().getRealPath("/");
				if(mail.sendMail(msg, ses.getAttribute("email").toString().trim(),"One time Password",filepath1))
				{
					 jf.recordusage(ses.getAttribute("userid").toString().trim(), "email");
		   			
				}
				}
				catch (Exception e) {
					// TODO: handle exception
					System.out.println("err in mail="+e.getMessage());
				}
			  
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp?type=sendOTP");
		}
		 return mv;
	}
	@SessionScope
	@RequestMapping("/sendOTP")
	public ModelAndView sendOTP(Documents eobj,HttpServletRequest request,HttpSession ses)
	{
	 ModelAndView mv=new ModelAndView();
	 
		 try {
			 eobj.setDocid( Integer.parseInt(request.getParameter("docId").trim()));
			 eobj.setFilePath(request.getParameter("path").trim());
			 eobj.setSeckey(request.getParameter("seckey").trim());
			 eobj.setUserid(ses.getAttribute("userid").toString().trim());
			 String otp= beans.RandomString.getAlphaNumericString(4);
			    mv.setViewName("OTPVerification.jsp");
			    System.out.println("path="+eobj.getFilePath()+" skey="+eobj.getSeckey());
				mv.addObject("path",eobj.getFilePath());
				mv.addObject("docId",eobj.getDocid());
				mv.addObject("seckey",eobj.getSeckey());
				mv.addObject("otp",otp);
				Mail mail=new   Mail();
				System.out.println("otp="+otp);
				CloudFuns jf=new CloudFuns();
				//String qr="select emailid,usernm from userdetails where userid='"+ses.getAttribute("userid").toString().trim()+"'";
				String qr="";
				if(ses.getAttribute("usertype").toString().equals("user"))
					qr="select emailid,usernm from userdetails where userid='"+ses.getAttribute("userid").toString().trim()+"'";
				else
					qr="select emailid,usernm from offices where userid='"+ses.getAttribute("userid").toString().trim()+"'";
			
				Vector v=jf.getValue(qr, 2);
				ses.setAttribute("username", v.elementAt(1).toString().trim());
				ses.setAttribute("email", v.elementAt(0).toString().trim());
				String msg="Dear "+ses.getAttribute("username").toString().trim()+", your one time password is "+otp;
				
				try
				{
					String filepath1=request.getServletContext().getRealPath("/");
				if(mail.sendMail(msg, ses.getAttribute("email").toString().trim(),"One time Password",filepath1))
				{
					 jf.recordusage(ses.getAttribute("userid").toString().trim(), "email");
		   			
				}
				}
				catch (Exception e) {
					// TODO: handle exception
					System.out.println("err in mail="+e.getMessage());
				}
			  
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp?type=sendOTP");
		}
		 return mv;
	}
	@SessionScope
	@RequestMapping("/sendOTP1")
	public ModelAndView sendOTP1(Documents eobj,HttpServletRequest request,HttpSession ses)
	{
	 ModelAndView mv=new ModelAndView();
	 
		 try {
			 eobj.setDocid( Integer.parseInt(request.getParameter("docId").trim()));
			 eobj.setFilePath(request.getParameter("path").trim());
			 eobj.setSeckey(request.getParameter("seckey").trim());
			 eobj.setUserid(ses.getAttribute("userid").toString().trim());
			 String otp= beans.RandomString.getAlphaNumericString(4);
			    mv.setViewName("OTPVerification1.jsp");
			    System.out.println("path="+eobj.getFilePath()+" skey="+eobj.getSeckey());
				mv.addObject("path",eobj.getFilePath());
				mv.addObject("docId",eobj.getDocid());
				mv.addObject("seckey",eobj.getSeckey());
				mv.addObject("otp",otp);
				Mail mail=new   Mail();
				System.out.println("otp="+otp);
				CloudFuns jf=new CloudFuns();
				String qr="";
				if(ses.getAttribute("usertype").toString().equals("user"))
					qr="select emailid,usernm from userdetails where userid='"+ses.getAttribute("userid").toString().trim()+"'";
				else
					qr="select emailid,usernm from offices where userid='"+ses.getAttribute("userid").toString().trim()+"'";
				//qr="select emailid,usernm from userdetails where userid='"+ses.getAttribute("userid").toString().trim()+"'";
				Vector v=jf.getValue(qr, 2);
				ses.setAttribute("username", v.elementAt(1).toString().trim());
				ses.setAttribute("email", v.elementAt(0).toString().trim());
				String msg="Dear "+ses.getAttribute("username").toString().trim()+", your one time password is "+otp;
				
				try
				{
					String filepath1=request.getServletContext().getRealPath("/");
				if(mail.sendMail(msg, ses.getAttribute("email").toString().trim(),"One time Password",filepath1))
				{
					 jf.recordusage(ses.getAttribute("userid").toString().trim(), "email");
		   			
				}
				}
				catch (Exception e) {
					// TODO: handle exception
					System.out.println("err in mail="+e.getMessage());
				}
			  
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp?type=sendOTP");
		}
		 return mv;
	}
	 
	@RequestMapping("/uploadDocsReg")
	public ModelAndView uploadDocsReg(Documents doc,HttpSession ses,HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		try {
			MultipartFile file=doc.getFile();
			 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
			 
			 
			 System.out.println("path="+filepath);
			 File f=new File(filepath);
			 f.mkdir();
			  
			 CloudFuns jf=new CloudFuns();
			    
			    int docid1=jf.FetchMax("docid", "documents");
				  doc.setDocid(docid1);
				 String fileName=docid1+"."+ file.getOriginalFilename().split("\\.")[1];
				 //file.transferTo(new File(filepath+"/"+fileName));
				 doc.setFilePath(fileName);
				 Encryption enc=new Encryption();
	   			 String seckey=RandomString.getAlphaNumericString(16);
	   			 enc.setSkey(seckey);
	   			 enc.encryption(file.getBytes(), filepath+"/"+fileName);
	   			// file.transferTo(new File(filepath+"/"+fileName));
	   			doc.setFilePath(fileName);
	   			doc.setSeckey(seckey);
		String st=doc.insert();
		CloudFuns cf=new CloudFuns();
		cf.recordusage(ses.getAttribute("userid").toString().trim(), "encryption");
		if(st.equals("success"))
		{
			 mv.setViewName("Success.jsp?type=docReg");
			 mv.addObject("activity","docReg");
		}
		else
		{
			 mv.setViewName("Failure.jsp?type=docReg");
			 mv.addObject("activity","docReg");
		}
		 
		}
		catch (Exception e) {
			// TODO: handle exception
			mv.setViewName("Failure.jsp?type=docReg");
			 mv.addObject("activity","docReg");
			System.out.println("err in createlogin="+e.getMessage());
		}
		 return mv;
	}
	@RequestMapping("/cloudadmin")
	public String cloudadmin()
	{
		return "Admin.jsp";
	}
	@RequestMapping("/police")
	public String police()
	{
		return "police.jsp";
	}
	@RequestMapping("/admin")
	public String admin()
	{
		return "Admin.jsp";
	}
	@RequestMapping("/RegVehicles")
	public String RegVehicles()
	{
		return "RegVehicles.jsp";
	}
	 
	@RequestMapping("/officer")
	public String officer()
	{
		return "Officer.jsp";
	}
	 @RequestMapping("/error")
    public String handleError() {
        //do something like logging
		return "home";
    }
  
    public String getErrorPath() {
        return "/error";
    }
    @RequestMapping("/check")
	public String check(CheckUser cu,HttpSession sess, HttpServletRequest request) {
		
		String st=cu.checkUser(request);
		String qr="";
		System.out.println("userid="+cu.getUserid()+" uytpe="+cu.getPswd());
		if(cu.getUtype().trim().equals("user"))
		{
			qr="select emailid,usernm from userdetails where userid='"+cu.getUserid()+"'";
		}
		else if(cu.getUtype().trim().equals("officer"))
		{
			qr="select emailid,usernm from offices where userid='"+cu.getUserid()+"'";
			System.out.println("typ="+qr);
		}
	
		if(cu.getUtype().trim().equals("user") || cu.getUtype().trim().equals("officer"))
		{
		JavaFuns jf=new JavaFuns();
		Vector v=jf.getValue(qr, 2);
		System.out.println("qr="+qr); 
		sess.setAttribute("email",v.elementAt(0).toString().trim());
	 	System.out.println("usernmae 111="+v.elementAt(0).toString().trim());
		sess.setAttribute("username",v.elementAt(1).toString().trim());
		System.out.println("username="+v.elementAt(1).toString().trim());
		}
		if(cu.getUtype().trim().equals("police") )
		{
		 
		sess.setAttribute("vid",request.getParameter("vid").toString().trim());
	 
		}
		return st;
	}	  
    
    @RequestMapping("/ViewCityPendingApps")
   	@SessionScope
   	public ModelAndView ViewCityPendingApps(HttpSession ses) {
   		
   		List<Vehicles> lst = new ArrayList<Vehicles>();
   		Vehicles vs = new Vehicles();
   		lst=vs.getVehicleDetails11(ses.getAttribute("userid").toString().trim());
   		ModelAndView mv=new ModelAndView();
   		mv.addObject("std",lst);
   		mv.setViewName("ViewMyVehicles1.jsp");
   		return mv;
   	}
    
    @RequestMapping("/ViewGuiltyVehicles")
	@SessionScope
	public ModelAndView ViewGuiltyVehicles(HttpSession ses,HttpServletRequest request) {
    	ModelAndView mv=new ModelAndView();
		List<Vehicles> lst = new ArrayList<Vehicles>();
		Vehicles vs = new Vehicles();
		int cnt=Integer.parseInt(request.getParameter("count").toString().trim());
		 
			lst=vs.getVehicleDetails12(cnt);
			mv.addObject("std",lst);
			mv.setViewName("ViewVehicles.jsp");
		 
		  
		return mv;
	}
    
    @RequestMapping("/viewMyVehicles")
	@SessionScope
	public ModelAndView viewMyVehicles(HttpSession ses) {
		
		List<Vehicles> lst = new ArrayList<Vehicles>();
		Vehicles vs = new Vehicles();
		lst=vs.getVehicleDetails(ses.getAttribute("userid").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("std",lst);
		mv.setViewName("ViewMyVehicles.jsp");
		return mv;
	}
    
   
	@RequestMapping("/DecryptDoc")
	public RedirectView DecryptDoc(Documents eobj,HttpServletRequest request,HttpSession ses)
	{
		ModelAndView mv=new ModelAndView();
	 
		 try {
			 
			// eobj.setUserid(ses.getAttribute("userid").toString().trim());
			// if(eobj.getOtp().equals(eobj.getUotp()))
			// {
				 System.out.println("otp verified");
			   
				 mv.setViewName("download.jsp");
				 String seckey=request.getParameter("seckey").toString();
				 Decryption dec=new Decryption();
				 dec.setSkey(seckey);
				 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
				 String filepath1=request.getServletContext().getRealPath("/")+"/Uploads/temp/"+request.getParameter("filePath").toString().trim();
				filepath+=request.getParameter("filePath").toString().trim();	
				 byte[] data=dec.decryption(Files.readAllBytes(Paths.get(filepath)));
				 Files.write(Paths.get(filepath1), data);
				 //String param= arr[2].trim()+"|"+arr[3].trim()+"|"+arr[4].trim()+"|"+arr[5].trim()+"|"+request.getParameter("filePath").toString().trim() ; 
				// String param= seckey+"|"+request.getParameter("filePath").toString().trim()+"|"+ses.getAttribute("userid").toString().trim() ;
				 System.out.println("param="+filepath);
				 
				 //mv.setViewName("Download.jsp");
				  mv.addObject("path","Uploads/temp/"+request.getParameter("filePath").toString().trim());
			// }
			// else
			// { 
			//	mv.setViewName("Failure.jsp?type=OTPAuth"); 
			// }
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp?type=OTPAuth"); 
		}
		 return new RedirectView("Uploads/temp/"+request.getParameter("filePath").toString().trim());
	}

    @SessionScope
	@RequestMapping("/OTPAuth")
	public ModelAndView OTPAuth(Documents eobj,HttpServletRequest request,HttpSession ses)
	{
		ModelAndView mv=new ModelAndView();
	 
		 try {
			 
			 eobj.setUserid(ses.getAttribute("userid").toString().trim());
			 if(eobj.getOtp().equals(eobj.getUotp()))
			 {
				 System.out.println("otp verified");
			   
				 mv.setViewName("download.jsp");
				 String seckey=request.getParameter("seckey").toString();
				 Decryption dec=new Decryption();
				 dec.setSkey(seckey);
				 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
				 String filepath1=request.getServletContext().getRealPath("/")+"/Uploads/temp/"+request.getParameter("filePath").toString().trim();
				filepath+=request.getParameter("filePath").toString().trim();	
				 byte[] data=dec.decryption(Files.readAllBytes(Paths.get(filepath)));
				 Files.write(Paths.get(filepath1), data);
				 //String param= arr[2].trim()+"|"+arr[3].trim()+"|"+arr[4].trim()+"|"+arr[5].trim()+"|"+request.getParameter("filePath").toString().trim() ; 
				// String param= seckey+"|"+request.getParameter("filePath").toString().trim()+"|"+ses.getAttribute("userid").toString().trim() ;
				 System.out.println("param="+filepath);
				 if(ses.getAttribute("usertype").toString().trim().equals("user"))
				 {
				 CloudFuns cf=new CloudFuns();
					cf.recordusage(ses.getAttribute("userid").toString().trim(), "decryption");
				 }
				 //mv.setViewName("Download.jsp");
				  mv.addObject("path","Uploads/temp/"+request.getParameter("filePath").toString().trim());
			 }
			 else
			 { 
				mv.setViewName("Failure.jsp?type=OTPAuth"); 
			 }
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp?type=OTPAuth"); 
		}
		 return mv;
	}

    @SessionScope
	@RequestMapping("/OTPAuthP")
	public ModelAndView OTPAuthP(Documents eobj,HttpServletRequest request,HttpSession ses)
	{
		ModelAndView mv=new ModelAndView();
	 
		 try {
			 
			  
			 if(eobj.getOtp().equals(eobj.getUotp()))
			 {
				 System.out.println("otp verified");
				 List<models.Documents> lst = new ArrayList<Documents>();
					//CallMinnerAPI vs = new CallMinnerAPI();
					Documents obj=new Documents();
					 
					  obj.getDocs12(ses.getAttribute("vid").toString().trim());
					
					mv.addObject("std",obj.getLst());
					//mv.setViewName("ViewMyDocs.jsp");
				 mv.setViewName("downloadDocs.jsp");
				 
			 }
			 else
			 { 
				mv.setViewName("Failure.jsp?type=OTPAuth"); 
			 }
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp?type=OTPAuth"); 
		}
		 return mv;
	}
    
    @SessionScope
	@RequestMapping("/OTPAuth1")
	public ModelAndView OTPAuth1(Documents eobj,HttpServletRequest request,HttpSession ses)
	{
		ModelAndView mv=new ModelAndView();
	 
		 try {
			 System.out.println("otp="+eobj.getOtp());
			 System.out.println("otp="+eobj.getUotp());
			 eobj.setUserid(ses.getAttribute("userid").toString().trim());
			 if(eobj.getOtp().equals(eobj.getUotp()))
			 {
				 System.out.println("otp verified");
			   
				 mv.setViewName("download.jsp");
				 String seckey=request.getParameter("seckey").toString();
				 Decryption dec=new Decryption();
				 dec.setSkey(seckey);
				 String filepath=request.getServletContext().getRealPath("/")+"/Vehicles/";
				 String filepath1=request.getServletContext().getRealPath("/")+"/Vehicles/temp/"+request.getParameter("filePath").toString().trim();
				filepath+=request.getParameter("filePath").toString().trim();	
				 byte[] data=dec.decryption(Files.readAllBytes(Paths.get(filepath)));
				 Files.write(Paths.get(filepath1), data);
				 //String param= arr[2].trim()+"|"+arr[3].trim()+"|"+arr[4].trim()+"|"+arr[5].trim()+"|"+request.getParameter("filePath").toString().trim() ; 
				// String param= seckey+"|"+request.getParameter("filePath").toString().trim()+"|"+ses.getAttribute("userid").toString().trim() ;
				 System.out.println("param="+filepath);
				 if(ses.getAttribute("usertype").toString().trim().equals("user"))
				 {
					 CloudFuns cf=new CloudFuns();
						cf.recordusage(ses.getAttribute("userid").toString().trim(), "decryption");
					
				 }
				 //mv.setViewName("Download.jsp");
				  mv.addObject("path","Vehicles/temp/"+request.getParameter("filePath").toString().trim());
			 }
			 else
			 { 
				mv.setViewName("Failure.jsp?type=OTPAuth"); 
			 }
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp?type=OTPAuth"); 
		}
		 return mv;
	}
	@RequestMapping("/viewUsers")
	@SessionScope
	public ModelAndView viewUsers() {
		
		List<Users> lst = new ArrayList<Users>();
		Users vs = new Users();
		lst=vs.getStudentReport();
		ModelAndView mv=new ModelAndView();
		mv.addObject("std",lst);
		mv.setViewName("ViewUsersReport.jsp");
		return mv;
	}
	@RequestMapping("/viewUserDetails")
	@SessionScope
	public ModelAndView viewUserDetails(HttpServletRequest request) {
		
		List<Users> lst = new ArrayList<Users>();
		Users vs = new Users();
		lst=vs.getUserReport(request.getParameter("userid").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("std",lst);
		mv.setViewName("ViewUsersReport.jsp");
		return mv;
	}
	 @RequestMapping("/FromPython")
	    public String FromPython(HttpServletRequest request) {
	     
			return "ViewGuiltyVehicles?cnt="+request.getParameter("count").toString().trim();
	    }
	  
	@RequestMapping("/viewOffice")
	@SessionScope
	public ModelAndView viewOffice() {
		
		List<ViewOffice> lst = new ArrayList<ViewOffice>();
		ViewOffice vs = new ViewOffice();
		lst=vs.getOfficeList();
		ModelAndView mv=new ModelAndView();
		mv.addObject("std",lst);
		System.out.println("lst="+lst.size());
		mv.setViewName("ViewOfficeReport.jsp");
		return mv;
	}
	@RequestMapping("/viewOffice1")
	@SessionScope
	public ModelAndView viewOffice1() {
		
		List<ViewOffice> lst = new ArrayList<ViewOffice>();
		ViewOffice vs = new ViewOffice();
		lst=vs.getOfficeList1();
		ModelAndView mv=new ModelAndView();
		mv.addObject("std",lst);
		System.out.println("lst="+lst.size());
		mv.setViewName("ViewOfficeReport1.jsp");
		return mv;
	}
	 @RequestMapping("/sendChallan")
		public ModelAndView sendChallan(Offices stu,HttpServletRequest request,HttpSession ses)
		{
			ModelAndView mv=new ModelAndView();
			 try
			 {MultipartFile file=stu.getFile();
			 String filepath=request.getServletContext().getRealPath("/")+"/Challan/";
			 
			 
			 System.out.println("path="+filepath);
			 File f=new File(filepath);
			 f.mkdir();
			  
			 try {
				 Random r=new Random();
				 int n=r.nextInt(99);
				 String fileName=request.getParameter("vid").toString().trim()+"_"+n+"."+ file.getOriginalFilename().split("\\.")[1];
				 file.transferTo(new File(filepath+"/"+fileName));
				 JavaFuns jf=new JavaFuns(); 
				 String qr="insert into challan(userid,vid,title,challanAmt,fpath) values('"+ses.getAttribute("userid").toString().trim()+"',"+request.getParameter("vid").toString().trim()+",'"+request.getParameter("title").toString().trim()+"',"+request.getParameter("amt").toString().trim()+",'"+fileName+"')";
				 System.out.println("qr="+qr);
				 String filepath1=request.getServletContext().getRealPath("/");
					if(jf.execute(qr))
					{
						Vector v1=jf.getValue("select emailid from userdetails where userid in (select userid from vehicles where vid="+request.getParameter("vid").toString().trim()+")", 1);
						Mail mail=new Mail();
						String msg="Dear User, You are violated RTO rules. RTO officer sent you challan, please check it in your account on RTO site.";
						try {
							if(mail.sendMail(msg, v1.elementAt(0).toString().trim(), "Challan Notification",filepath1))
							{}
						}
						catch (Exception e) {
							// TODO: handle exception
							System.out.println("eerr1="+e.getMessage());
						}
						mv.setViewName("Success.jsp");
					}
					else
						mv.setViewName("Failure.jsp");
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("eerr="+e.getMessage());
				 mv.setViewName("Failure.jsp");
			}}
			 catch (Exception e) {
					// TODO: handle exception
				 mv.setViewName("Failure.jsp");
				}
			 mv.addObject("activity","challanReg");
			 return mv;
			
		}	
	 @RequestMapping("/registerOffice1")
		public ModelAndView registerdealer1(Offices stu,ServletRequest request)
		{
			ModelAndView mv=new ModelAndView();
			 try
			 {MultipartFile file=stu.getFile();
			 String filepath=request.getServletContext().getRealPath("/")+"/UploadsOffice/";
			 
			 
			 System.out.println("path="+filepath);
			 File f=new File(filepath);
			 f.mkdir();
			  
			 try {
				  
				 String fileName=stu.getUserid()+"."+ file.getOriginalFilename().split("\\.")[1];
				 file.transferTo(new File(filepath+"/"+fileName));
				 stu.setPath(fileName);
				 String st=stu.addNewUser();
					if(st.equals("success"))
						mv.setViewName("Success.jsp");
					else
						mv.setViewName("Failure.jsp");
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 mv.setViewName("Failure.jsp");
			}}
			 catch (Exception e) {
					// TODO: handle exception
				 mv.setViewName("Failure.jsp");
				}
			 mv.addObject("activity","PoliceReg");
			 return mv;
			
		}	 
    @RequestMapping("/registerOffice")
	public ModelAndView registerdealer(Offices stu,ServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		 try
		 {MultipartFile file=stu.getFile();
		 String filepath=request.getServletContext().getRealPath("/")+"/UploadsOffice/";
		 
		 
		 System.out.println("path="+filepath);
		 File f=new File(filepath);
		 f.mkdir();
		  
		 try {
			  
			 String fileName=stu.getUserid()+"."+ file.getOriginalFilename().split("\\.")[1];
			 file.transferTo(new File(filepath+"/"+fileName));
			 stu.setPath(fileName);
			 String st=stu.addNewUser();
				if(st.equals("success"))
					mv.setViewName("Success.jsp");
				else
					mv.setViewName("Failure.jsp");
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 mv.setViewName("Failure.jsp");
		}}
		 catch (Exception e) {
				// TODO: handle exception
			 mv.setViewName("Failure.jsp");
			}
		 mv.addObject("activity","OfficeReg");
		 return mv;
		
	}	 
    @RequestMapping("/generateQR")
   	public RedirectView  generateQR(Vehicles stu,ServletRequest request)
   	{
   		ModelAndView mv=new ModelAndView();
   	 int vehicleid=stu.getVid();
   		 try
   		 {  
   			 
   		
   		 String filepath1=request.getServletContext().getRealPath("/")+"/QRCodes/"+vehicleid+".png";
   		 
   		 
   		 System.out.println("path="+filepath1);
   		 File f=new File(filepath1);
   		// f.mkdir();
   		  
   		 try {
   			  
   			 
   			 QRCodeGenerator.generateQRCode("http://"+IPAddress.getIP()+":8080/verify?vid="+vehicleid, filepath1, 200, 200);
   			   
   			  
   		 }
   		 catch (Exception e) {
   			// TODO: handle exception
   			 
   		}}
   		 catch (Exception e) {
   				// TODO: handle exception
   			 
   			}
   		  
   		 return new RedirectView("QRCodes/"+vehicleid+".png");
   		
   	}	 
    @RequestMapping("/registerVehicles")
   	public ModelAndView registerVehicles(Vehicles stu,ServletRequest request)
   	{
   		ModelAndView mv=new ModelAndView();
   		 try
   		 {MultipartFile file=stu.getFile();
   		 String filepath=request.getServletContext().getRealPath("/")+"/Vehicles/";
   		 int vehicleid=stu.getId();
   		 String filepath1=request.getServletContext().getRealPath("/")+"/QRCodes/"+vehicleid+".png";
   		 
   		 
   		 System.out.println("path="+filepath);
   		 File f=new File(filepath);
   		 f.mkdir();
   		  
   		 try {
   			  
   			 String fileName=vehicleid+"."+ file.getOriginalFilename().split("\\.")[1];
   			Encryption enc=new Encryption();
   			 String seckey=RandomString.getAlphaNumericString(16);
   			 enc.setSkey(seckey);
   			 enc.encryption(file.getBytes(), filepath+"/"+fileName);
   			// file.transferTo(new File(filepath+"/"+fileName));
   			 stu.setPath(fileName);
   			 stu.setSeckey(seckey);
   			 QRCodeGenerator.generateQRCode("http://"+IPAddress.getIP()+":8080/verify?vid="+vehicleid, filepath1, 200, 200);
   			 String st=stu.addVehicles();
   				if(st.equals("success"))
   					mv.setViewName("Success.jsp");
   				else
   					mv.setViewName("Failure.jsp");
   		 }
   		 catch (Exception e) {
   			// TODO: handle exception
   			 mv.setViewName("Failure.jsp");
   		}}
   		 catch (Exception e) {
   				// TODO: handle exception
   			 mv.setViewName("Failure.jsp");
   			}
   		 mv.addObject("activity","vehicleReg");
   		 return mv;
   		
   	}	 
    
	@RequestMapping("/registeruser")
	public ModelAndView registeruser(Users stu,ServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		 try
		 {MultipartFile file=stu.getFile();
		 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
		 
		 
		 System.out.println("path="+filepath);
		 File f=new File(filepath);
		 f.mkdir();
		  
		 try {
			  
			 String fileName=stu.getUserid()+"."+ file.getOriginalFilename().split("\\.")[1];
			 file.transferTo(new File(filepath+"/"+fileName));
			 stu.setPath(fileName);
			 String st=stu.addNewUser();
				if(st.equals("success"))
					mv.setViewName("Success.jsp");
				else
					mv.setViewName("Failure.jsp");
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 mv.setViewName("Failure.jsp");
		}}
		 catch (Exception e) {
				// TODO: handle exception
			 mv.setViewName("Failure.jsp");
			}
		 mv.addObject("activity","UserReg");
		 return mv;
		
	}
	@RequestMapping("/updateuser")
	public ModelAndView updateuser(Users stu,ServletRequest request,HttpSession ses)
	{String fileName="NA";
		
	ModelAndView mv=new ModelAndView();
	try
		 {
			 stu.setUserid(ses.getAttribute("userid").toString().trim());
			 
		  
		 try {
			 MultipartFile file=stu.getFile();
			 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
			 
			 
			 System.out.println("path="+filepath);
			 File f=new File(filepath);
			 f.mkdir();
			  fileName=stu.getUserid()+"."+ file.getOriginalFilename().split("\\.")[1];
			 file.transferTo(new File(filepath+"/"+fileName));
			 
		 }
		 catch (Exception e) {
			// TODO: handle exception
			// return "UserRegFailure.jsp";
		}
		 if(!fileName.equals("NA"))
		 {
			 ses.setAttribute("photo", fileName);
		 }
		 stu.setPath(fileName);
		 String st=stu.updateUser(stu.getUserid());
		 if(st.equals("success"))
				mv.setViewName("Success.jsp");
			else
				mv.setViewName("Failure.jsp");
		 }
		 catch (Exception e) {
			 System.out.println("in update="+e.getMessage());
				// TODO: handle exception
			 mv.setViewName("Failure.jsp");
			}
		 mv.addObject("activity","StudProfile");
		 return mv;
	}
	 
	@RequestMapping("/forgetpassword")
	public String forgetpassword() {
		
		return("ForgetPassword.jsp");
	}
	@RequestMapping("/recoverpassword")
	public String recoverpassword(PasswordRecovery pr) {
		
		String sts=pr.getNewPassword();
		
		return(sts);
	}
	@RequestMapping("/ChangePass")
	public String ChangePass()
	{
		return "ChangePass.jsp";
	}
	@RequestMapping("/ChangePassService")
	public ModelAndView ChangePassService(Pass eobj,HttpSession ses)
	{
		ModelAndView mv=new ModelAndView();
		 try
		 {
			 
			 eobj.setUserid(ses.getAttribute("userid").toString().trim());
			 if(eobj.changePassword())
			 { 
				 mv.setViewName("Success.jsp");
			 }
			 else
			 { 
				 mv.setViewName("Failure.jsp");
			 }
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 mv.setViewName("Failure.jsp");
		}
		 mv.addObject("activity","changePass");
		 return mv;
	}
}
	
	