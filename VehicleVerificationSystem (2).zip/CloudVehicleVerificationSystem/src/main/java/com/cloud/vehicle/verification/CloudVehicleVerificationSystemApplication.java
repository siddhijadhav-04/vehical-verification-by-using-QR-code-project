package com.cloud.vehicle.verification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudVehicleVerificationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudVehicleVerificationSystemApplication.class, args);
	}

}
