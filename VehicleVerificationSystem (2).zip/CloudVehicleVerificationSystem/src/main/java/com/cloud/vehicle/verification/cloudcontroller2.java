package com.cloud.vehicle.verification;



import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class cloudcontroller2 {

    // Aadhaar Verification Step
    @PostMapping("/verifyAadhaar")
    public String verifyAadhaar(@RequestParam String aadhaar, Model model, HttpSession session) {

        // Validate Aadhaar (12 digits)
        if (aadhaar.length() != 12) {
            model.addAttribute("msg", "Invalid Aadhaar Number");
            return "aadhaar";
        }

        // Generate OTP
        int otp = (int) (Math.random() * 900000) + 100000;

        // Store in session
        session.setAttribute("otp", otp);
        session.setAttribute("aadhaar", aadhaar);

        System.out.println("OTP: " + otp); // For testing

        model.addAttribute("msg", "OTP Sent Successfully");
        return "verifyOtp";
    }

    // OTP Check
    @PostMapping("/checkOtp")
    public String checkOtp(@RequestParam int userOtp, HttpSession session, Model model) {

        int otp = (int) session.getAttribute("otp");

        if (userOtp == otp) {
            session.setAttribute("aadhaarVerified", true);
            model.addAttribute("msg", "Aadhaar Verified Successfully");
            return "success";
        } else {
            model.addAttribute("msg", "Invalid OTP");
            return "verifyOtp";
        }
    }
}