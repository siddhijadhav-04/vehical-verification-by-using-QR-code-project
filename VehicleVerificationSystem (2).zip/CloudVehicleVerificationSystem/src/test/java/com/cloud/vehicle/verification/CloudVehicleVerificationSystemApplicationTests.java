package com.cloud.vehicle.verification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudVehicleVerificationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
